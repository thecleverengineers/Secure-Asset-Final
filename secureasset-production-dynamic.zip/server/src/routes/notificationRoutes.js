import { Router } from 'express';
import { authenticate } from '../middleware/auth.js';
import { unreadCount, markAllRead } from '../controllers/notificationController.js';
const router = Router();
router.get('/unread-count', authenticate, unreadCount);
router.post('/mark-all-read', authenticate, markAllRead);
export default router;
