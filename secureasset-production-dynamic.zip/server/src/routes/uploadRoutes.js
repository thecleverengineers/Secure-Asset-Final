import fs from 'fs';
import path from 'path';
import { Router } from 'express';
import multer from 'multer';
import { env } from '../config/env.js';
import { authenticate } from '../middleware/auth.js';
import { uploadDocument } from '../controllers/uploadController.js';

fs.mkdirSync(env.UPLOAD_DIR, { recursive: true });
const allowed = new Set(['image/jpeg', 'image/png', 'image/webp', 'application/pdf', 'text/csv', 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet']);
const storage = multer.diskStorage({
  destination: (_req, _file, cb) => cb(null, env.UPLOAD_DIR),
  filename: (_req, file, cb) => cb(null, `${Date.now()}-${Math.random().toString(36).slice(2, 10)}${path.extname(file.originalname).toLowerCase()}`),
});
const upload = multer({ storage, limits: { fileSize: env.MAX_FILE_MB * 1024 * 1024 }, fileFilter: (_req, file, cb) => allowed.has(file.mimetype) ? cb(null, true) : cb(new Error('Unsupported file type')) });
const router = Router();
router.post('/document', authenticate, upload.single('file'), uploadDocument);
export default router;
