import { Router } from 'express';
import rateLimit from 'express-rate-limit';
import { register, login, refresh, logout, me, sendOtp, verifyOtp, forgotPassword, resetPassword } from '../controllers/authController.js';
import { authenticate } from '../middleware/auth.js';

const router = Router();
const limiter = rateLimit({ windowMs: 15 * 60 * 1000, limit: 30, standardHeaders: true, legacyHeaders: false });
router.post('/register', limiter, register);
router.post('/login', limiter, login);
router.post('/refresh', limiter, refresh);
router.post('/logout', authenticate, logout);
router.get('/me', authenticate, me);
router.post('/send-otp', limiter, sendOtp);
router.post('/verify-otp', limiter, verifyOtp);
router.post('/forgot-password', limiter, forgotPassword);
router.post('/reset-password', limiter, resetPassword);
export default router;
