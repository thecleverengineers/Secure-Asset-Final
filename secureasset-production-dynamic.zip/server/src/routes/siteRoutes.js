import { Router } from 'express';
import multer from 'multer';
import { getPublicSite, submitSiteEnquiry, getPublicPropertyStructure } from '../controllers/siteController.js';
import { uploadSiteAsset } from '../controllers/siteAssetController.js';
import { authenticate } from '../middleware/auth.js';

const router = Router();
const imageUpload = multer({ storage: multer.memoryStorage(), limits: { fileSize: 8 * 1024 * 1024, files: 1 } });
router.get('/config', getPublicSite);
router.post('/enquiries', submitSiteEnquiry);
router.get('/properties/:id/structure', getPublicPropertyStructure);
router.post('/admin-assets', authenticate, imageUpload.single('file'), uploadSiteAsset);
export default router;
