import { Router } from 'express';
import { authenticate } from '../middleware/auth.js';
import { exportCsv } from '../controllers/reportController.js';
const router = Router();
router.get('/:resource.csv', authenticate, exportCsv);
export default router;
