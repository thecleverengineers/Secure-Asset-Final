import {
  SurveyorSubscription, SurveyorVerification, SurveyEquipment, SurveyProject, Payment, Notification,
} from '../models/index.js';
import { ensureDefaultSurveyorPlans, refreshSurveyorSubscriptionState } from './surveyorSubscription.js';

async function notifyOnce(user, key, title, message, actionUrl, category = 'survey') {
  if (await Notification.exists({ user, 'metadata.key': key })) return;
  await Notification.create({ user, title, message, actionUrl, category, metadata: { key } });
}

export async function runSurveyorLifecycleMaintenance() {
  await ensureDefaultSurveyorPlans();
  const now = new Date(); const upcoming = new Date(now.getTime() + 8 * 86400000);
  const subscriptions = await SurveyorSubscription.find({ status: { $in: ['trial', 'active', 'expiring_soon', 'grace_period'] }, expiresAt: { $lte: upcoming } }).lean();
  for (const sub of subscriptions) {
    await refreshSurveyorSubscriptionState(sub.user);
    const days = Math.ceil((new Date(sub.expiresAt).getTime() - now.getTime()) / 86400000);
    if ([7, 3, 1, 0].includes(days)) await notifyOnce(sub.user, `surveyor-sub-expiry-${sub._id}-${days}`, days > 0 ? 'Surveyor subscription expiring' : 'Surveyor subscription grace period', days > 0 ? `Your ${sub.planKey} plan expires in ${days} day${days === 1 ? '' : 's'}.` : 'Renew now to keep your public profile, services and quotation access active.', '/app/surveyor-subscription');
  }

  const licenceWindow = new Date(now.getTime() + 30 * 86400000);
  for (const verification of await SurveyorVerification.find({ status: 'verified', licenceExpiryDate: { $gte: now, $lte: licenceWindow } }).lean()) {
    const days = Math.ceil((new Date(verification.licenceExpiryDate).getTime() - now.getTime()) / 86400000);
    await notifyOnce(verification.user, `surveyor-licence-${verification._id}-${new Date(verification.licenceExpiryDate).toISOString().slice(0, 10)}`, 'Professional licence expiring', `Your professional licence expires in ${days} days. Upload the renewed licence to keep verification active.`, '/app/surveyor-verification');
  }

  const equipmentWindow = new Date(now.getTime() + 14 * 86400000);
  for (const equipment of await SurveyEquipment.find({ nextCalibrationDate: { $gte: now, $lte: equipmentWindow }, availability: { $ne: 'retired' } }).lean()) {
    await notifyOnce(equipment.surveyor, `equipment-calibration-${equipment._id}-${new Date(equipment.nextCalibrationDate).toISOString().slice(0, 10)}`, 'Equipment calibration due', `${equipment.name} is due for calibration on ${new Date(equipment.nextCalibrationDate).toLocaleDateString('en-IN')}.`, '/app/survey-equipment');
  }

  const projectWindow = new Date(now.getTime() + 2 * 86400000);
  for (const project of await SurveyProject.find({ dueDate: { $gte: now, $lte: projectWindow }, status: { $nin: ['completed', 'cancelled'] } }).lean()) {
    await notifyOnce(project.surveyor, `survey-project-due-${project._id}-${new Date(project.dueDate).toISOString().slice(0, 10)}`, 'Survey project deadline approaching', `${project.projectNumber || 'A survey project'} is due on ${new Date(project.dueDate).toLocaleDateString('en-IN')}.`, '/app/survey-projects');
  }

  await Payment.updateMany({ type: { $in: ['survey_advance', 'survey_milestone', 'survey_final'] }, status: 'pending', dueDate: { $lt: now } }, { status: 'overdue' });
}

export function scheduleSurveyorLifecycleMaintenance() {
  const execute = () => runSurveyorLifecycleMaintenance().catch((error) => console.error('Surveyor lifecycle maintenance failed', error));
  const first = setTimeout(execute, 3000); first.unref();
  const interval = setInterval(execute, 6 * 60 * 60 * 1000); interval.unref();
  return () => { clearTimeout(first); clearInterval(interval); };
}
