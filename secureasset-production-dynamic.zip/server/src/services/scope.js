import mongoose from 'mongoose';

export function assignedPropertyIds(user) {
  return (user.assignedProperties || []).map((id) => new mongoose.Types.ObjectId(id));
}

export function buildScope(user, resource) {
  if (!user || user.role === 'admin') return {};
  const uid = user._id;
  const propertyIds = assignedPropertyIds(user);

  if (user.role === 'manager') {
    if (resource === 'properties') return { $or: [{ manager: uid }, { _id: { $in: propertyIds } }] };
    if (['units', 'tenants', 'leases', 'surveys', 'applications', 'payments', 'complaints', 'property-spaces', 'property-media', 'tenant-interviews', 'property-visits', 'tenancies', 'rental-invoices', 'utility-readings'].includes(resource)) {
      return { property: { $in: propertyIds } };
    }
    if (resource === 'tenant-profiles' || resource === 'tenant-kyc' || resource === 'occupants') return {};
    if (resource === 'reminder-rules') return { $or: [{ property: { $in: propertyIds } }, { owner: uid }] };
    if (resource === 'site-enquiries') return {};
    if (resource === 'approvals') return { $or: [{ property: { $in: propertyIds } }, { requester: uid }] };
    if (resource === 'documents') return { $or: [{ property: { $in: propertyIds } }, { owner: uid }] };
    if (resource === 'messages') return { $or: [{ sender: uid }, { recipients: uid }] };
    if (resource === 'notifications') return { user: uid };
    if (resource === 'attendance') return {};
    if (resource === 'audit-logs') return { user: uid };
    return {};
  }

  if (user.role === 'tenant') {
    const scopes = {
      properties: { owner: uid }, subscriptions: { user: uid }, tenants: { user: uid }, leases: { tenant: uid }, payments: { $or: [{ payer: uid }, { payee: uid }] }, complaints: { raisedBy: uid },
      documents: { owner: uid }, notifications: { user: uid }, messages: { $or: [{ sender: uid }, { recipients: uid }] },
      approvals: { requester: uid }, applications: { $or: [{ applicant: uid }, { landlord: uid }] },
      'surveyor-subscriptions': { user: uid }, 'surveyor-verifications': { user: uid }, 'surveyor-profiles': { user: uid },
      'survey-services': { surveyor: uid },
      'survey-jobs': { $or: [{ client: uid }, { hiredSurveyor: uid }, { invitedSurveyors: uid }, { shortlistedSurveyors: uid }] },
      'survey-quotations': { $or: [{ surveyor: uid }, { client: uid }] },
      'survey-projects': { $or: [{ surveyor: uid }, { client: uid }] },
      'site-visits': { $or: [{ surveyor: uid }, { client: uid }] },
      'field-data': { surveyor: uid }, 'survey-equipment': { surveyor: uid },
      'survey-reports': { $or: [{ surveyor: uid }, { client: uid }] },
      'survey-team': { owner: uid }, 'survey-clients': { surveyor: uid },
      'survey-reviews': { $or: [{ surveyor: uid }, { client: uid }] },
      'survey-disputes': { $or: [{ raisedBy: uid }, { against: uid }] }, 'survey-promotions': { surveyor: uid },
      'property-spaces': { owner: uid }, 'property-media': { owner: uid },
      'tenant-profiles': { user: uid }, 'tenant-kyc': { user: uid }, 'occupants': { tenant: uid },
      'tenant-interviews': { $or: [{ landlord: uid }, { tenant: uid }] },
      'property-visits': { $or: [{ landlord: uid }, { requester: uid }] },
      tenancies: { $or: [{ landlord: uid }, { tenant: uid }] },
      'rental-invoices': { $or: [{ landlord: uid }, { tenant: uid }] },
      'utility-readings': { $or: [{ landlord: uid }, { tenant: uid }] },
      'reminder-rules': { owner: uid }, 'property-promotions': { owner: uid },
    };
    return scopes[resource] || { _id: null };
  }

  if (user.role === 'user') {
    const scopes = {
      applications: { applicant: uid }, payments: { $or: [{ payer: uid }, { payee: uid }] }, complaints: { raisedBy: uid }, documents: { owner: uid },
      notifications: { user: uid }, messages: { $or: [{ sender: uid }, { recipients: uid }] }, approvals: { requester: uid },
    };
    return scopes[resource] || { _id: null };
  }

  if (user.role === 'surveyor') {
    const scopes = {
      surveys: { surveyor: uid }, attendance: { user: uid }, documents: { owner: uid }, notifications: { user: uid },
      messages: { $or: [{ sender: uid }, { recipients: uid }] }, approvals: { requester: uid },
    };
    return scopes[resource] || { _id: null };
  }

  return { _id: null };
}
