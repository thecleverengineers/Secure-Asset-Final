import crypto from 'crypto';
import fs from 'fs';
import fsp from 'fs/promises';
import path from 'path';
import { Readable, PassThrough } from 'stream';
import { pipeline } from 'stream/promises';
import { env } from '../config/env.js';

const MAGIC = Buffer.from('SAV1');
const HEADER_BYTES = 16; // 4-byte magic + 12-byte IV
const TAG_BYTES = 16;
function safeSegment(value = '') { return String(value).replace(/[^a-zA-Z0-9._-]/g, '_').slice(0, 120); }
function localPath(key) { return path.resolve(env.VAULT_STORAGE_DIR, key); }
function encryptionKey() {
  if (!env.VAULT_ENCRYPTION_KEY) return null;
  return crypto.createHash('sha256').update(env.VAULT_ENCRYPTION_KEY).digest();
}
async function s3Client() {
  const { S3Client } = await import('@aws-sdk/client-s3');
  return new S3Client({ region: env.S3_REGION, endpoint: env.S3_ENDPOINT || undefined, forcePathStyle: Boolean(env.S3_ENDPOINT), credentials: env.S3_ACCESS_KEY_ID ? { accessKeyId: env.S3_ACCESS_KEY_ID, secretAccessKey: env.S3_SECRET_ACCESS_KEY } : undefined });
}
export function buildStorageKey(ownerId, originalName, namespace = 'files') {
  const date = new Date(); const ext = path.extname(originalName).toLowerCase();
  return `${namespace}/${safeSegment(ownerId)}/${date.getUTCFullYear()}/${String(date.getUTCMonth() + 1).padStart(2, '0')}/${crypto.randomUUID()}${ext}`;
}
async function encryptBuffer(buffer) {
  const key = encryptionKey(); if (!key) return buffer;
  const iv = crypto.randomBytes(12); const cipher = crypto.createCipheriv('aes-256-gcm', key, iv);
  return Buffer.concat([MAGIC, iv, cipher.update(buffer), cipher.final(), cipher.getAuthTag()]);
}
async function decryptBuffer(buffer) {
  if (!buffer.subarray(0, 4).equals(MAGIC)) return buffer;
  const key = encryptionKey(); if (!key) throw new Error('VAULT_ENCRYPTION_KEY is required to read encrypted local files');
  const iv = buffer.subarray(4, HEADER_BYTES); const tag = buffer.subarray(buffer.length - TAG_BYTES); const ciphertext = buffer.subarray(HEADER_BYTES, buffer.length - TAG_BYTES);
  const decipher = crypto.createDecipheriv('aes-256-gcm', key, iv); decipher.setAuthTag(tag);
  return Buffer.concat([decipher.update(ciphertext), decipher.final()]);
}
export async function saveBuffer(buffer, key, contentType = 'application/octet-stream') {
  if (env.STORAGE_DRIVER === 's3') {
    const { PutObjectCommand } = await import('@aws-sdk/client-s3');
    await (await s3Client()).send(new PutObjectCommand({ Bucket: env.S3_BUCKET, Key: key, Body: buffer, ContentType: contentType, ServerSideEncryption: env.S3_SSE || undefined }));
    return { driver: 's3', key };
  }
  const filePath = localPath(key); await fsp.mkdir(path.dirname(filePath), { recursive: true }); await fsp.writeFile(filePath, await encryptBuffer(buffer), { mode: 0o600 });
  return { driver: 'local', key };
}
export async function saveFile(sourcePath, key, contentType = 'application/octet-stream') {
  if (env.STORAGE_DRIVER === 's3') { const buffer = await fsp.readFile(sourcePath); const result = await saveBuffer(buffer, key, contentType); await fsp.unlink(sourcePath).catch(() => {}); return result; }
  const destination = localPath(key); await fsp.mkdir(path.dirname(destination), { recursive: true });
  const keyBytes = encryptionKey();
  if (!keyBytes) await fsp.rename(sourcePath, destination).catch(async () => { await fsp.copyFile(sourcePath, destination); await fsp.unlink(sourcePath); });
  else {
    const iv = crypto.randomBytes(12); const cipher = crypto.createCipheriv('aes-256-gcm', keyBytes, iv); const output = fs.createWriteStream(destination, { mode: 0o600 }); output.write(Buffer.concat([MAGIC, iv]));
    await pipeline(fs.createReadStream(sourcePath), cipher, output); await fsp.appendFile(destination, cipher.getAuthTag()); await fsp.unlink(sourcePath).catch(() => {});
  }
  await fsp.chmod(destination, 0o600).catch(() => {}); return { driver: 'local', key };
}
export async function readBuffer(driver, key) {
  if (driver === 's3') { const { GetObjectCommand } = await import('@aws-sdk/client-s3'); const response = await (await s3Client()).send(new GetObjectCommand({ Bucket: env.S3_BUCKET, Key: key })); return Buffer.from(await response.Body.transformToByteArray()); }
  return decryptBuffer(await fsp.readFile(localPath(key)));
}
export async function createReadStream(driver, key) {
  if (driver === 's3') { const { GetObjectCommand } = await import('@aws-sdk/client-s3'); const response = await (await s3Client()).send(new GetObjectCommand({ Bucket: env.S3_BUCKET, Key: key })); return response.Body instanceof Readable ? response.Body : Readable.fromWeb(response.Body); }
  const filePath = localPath(key); const handle = await fsp.open(filePath, 'r'); const head = Buffer.alloc(HEADER_BYTES); await handle.read(head, 0, HEADER_BYTES, 0); const stat = await handle.stat(); await handle.close();
  if (!head.subarray(0, 4).equals(MAGIC)) return fs.createReadStream(filePath);
  const keyBytes = encryptionKey(); if (!keyBytes) throw new Error('VAULT_ENCRYPTION_KEY is required to read encrypted local files');
  const tagHandle = await fsp.open(filePath, 'r'); const tag = Buffer.alloc(TAG_BYTES); await tagHandle.read(tag, 0, TAG_BYTES, stat.size - TAG_BYTES); await tagHandle.close();
  const decipher = crypto.createDecipheriv('aes-256-gcm', keyBytes, head.subarray(4, HEADER_BYTES)); decipher.setAuthTag(tag);
  const output = new PassThrough(); pipeline(fs.createReadStream(filePath, { start: HEADER_BYTES, end: stat.size - TAG_BYTES - 1 }), decipher, output).catch((error) => output.destroy(error)); return output;
}
export async function deleteObject(driver, key) {
  if (!key) return;
  if (driver === 's3') { const { DeleteObjectCommand } = await import('@aws-sdk/client-s3'); await (await s3Client()).send(new DeleteObjectCommand({ Bucket: env.S3_BUCKET, Key: key })); return; }
  await fsp.unlink(localPath(key)).catch(() => {});
}
export async function objectExists(driver, key) {
  if (driver === 's3') { const { HeadObjectCommand } = await import('@aws-sdk/client-s3'); try { await (await s3Client()).send(new HeadObjectCommand({ Bucket: env.S3_BUCKET, Key: key })); return true; } catch { return false; } }
  try { await fsp.access(localPath(key)); return true; } catch { return false; }
}
export function tempUploadPath(sessionId, chunkIndex) { return path.resolve(env.VAULT_TEMP_DIR, safeSegment(sessionId), `${Number(chunkIndex)}.part`); }
export async function ensureStorageDirectories() { await Promise.all([fsp.mkdir(env.VAULT_STORAGE_DIR, { recursive: true }), fsp.mkdir(env.VAULT_TEMP_DIR, { recursive: true })]); }
