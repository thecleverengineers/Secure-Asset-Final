import { Server } from 'socket.io';
import { verifyAccessToken } from '../utils/tokens.js';
import { User, Message } from '../models/index.js';
import { env } from '../config/env.js';

export function attachSocket(server) {
  const io = new Server(server, { cors: { origin: env.CLIENT_URL.split(',').map((x) => x.trim()), credentials: true } });
  io.use(async (socket, next) => {
    try {
      const token = socket.handshake.auth?.token;
      const payload = verifyAccessToken(token);
      const user = await User.findById(payload.sub);
      if (!user || user.status !== 'active') throw new Error('Unauthorized');
      socket.user = user; next();
    } catch { next(new Error('Unauthorized')); }
  });
  io.on('connection', (socket) => {
    socket.join(`user:${socket.user._id}`);
    socket.on('conversation:join', (conversationId) => socket.join(`conversation:${conversationId}`));
    socket.on('message:send', async (payload, callback) => {
      try {
        const message = await Message.create({ ...payload, sender: socket.user._id });
        const populated = await message.populate(['sender', 'recipients']);
        io.to(`conversation:${message.conversationId}`).emit('message:new', populated);
        for (const recipient of message.recipients) io.to(`user:${recipient._id || recipient}`).emit('message:new', populated);
        callback?.({ success: true, data: populated });
      } catch (error) { callback?.({ success: false, message: error.message }); }
    });
  });
  return io;
}
