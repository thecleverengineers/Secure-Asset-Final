import http from 'http';
import { createApp } from './app.js';
import { connectDatabase, disconnectDatabase } from './config/db.js';
import { env } from './config/env.js';
import { attachSocket } from './services/socket.js';
import { scheduleSurveyorLifecycleMaintenance } from './services/surveyorLifecycle.js';
import { ensureStorageDirectories } from './services/storage.js';

await ensureStorageDirectories();
await connectDatabase();
const app = createApp();
const server = http.createServer(app);
attachSocket(server);
const stopSurveyorMaintenance = scheduleSurveyorLifecycleMaintenance();
server.listen(env.PORT, () => console.log(`SecureAsset API listening on http://localhost:${env.PORT}`));

async function shutdown(signal) {
  console.log(`${signal} received; shutting down`);
  server.close(async () => { stopSurveyorMaintenance(); await disconnectDatabase(); process.exit(0); });
  setTimeout(() => process.exit(1), 10000).unref();
}
process.on('SIGTERM', () => shutdown('SIGTERM'));
process.on('SIGINT', () => shutdown('SIGINT'));
process.on('unhandledRejection', (error) => { console.error(error); shutdown('unhandledRejection'); });
