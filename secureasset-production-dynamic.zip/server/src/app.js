import path from 'path';
import fs from 'fs';
import express from 'express';
import cors from 'cors';
import helmet from 'helmet';
import compression from 'compression';
import cookieParser from 'cookie-parser';
import morgan from 'morgan';
import { env } from './config/env.js';
import authRoutes from './routes/authRoutes.js';
import publicRoutes from './routes/publicRoutes.js';
import resourceRoutes from './routes/resourceRoutes.js';
import dashboardRoutes from './routes/dashboardRoutes.js';
import uploadRoutes from './routes/uploadRoutes.js';
import attendanceRoutes from './routes/attendanceRoutes.js';
import reportRoutes from './routes/reportRoutes.js';
import notificationRoutes from './routes/notificationRoutes.js';
import surveyRoutes from './routes/surveyRoutes.js';
import subscriptionRoutes from './routes/subscriptionRoutes.js';
import surveyorSubscriptionRoutes from './routes/surveyorSubscriptionRoutes.js';
import driveRoutes from './routes/driveRoutes.js';
import drivePublicRoutes from './routes/drivePublicRoutes.js';
import siteRoutes from './routes/siteRoutes.js';
import propertyManagementRoutes from './routes/propertyManagementRoutes.js';
import { notFound, errorHandler } from './middleware/error.js';

export function createApp() {
  const app = express();
  app.set('trust proxy', 1);
  app.use(helmet({
    crossOriginResourcePolicy: { policy: 'cross-origin' },
    contentSecurityPolicy: {
      directives: {
        defaultSrc: ["'self'"],
        baseUri: ["'self'"],
        objectSrc: ["'none'"],
        frameAncestors: ["'none'"],
        scriptSrc: ["'self'"],
        styleSrc: ["'self'", "'unsafe-inline'"],
        imgSrc: ["'self'", 'data:', 'blob:', 'https:'],
        mediaSrc: ["'self'", 'blob:', 'https:'],
        frameSrc: ["'self'", 'blob:'],
        fontSrc: ["'self'", 'data:', 'https:'],
        connectSrc: ["'self'", ...env.CLIENT_URL.split(',').map((value) => value.trim()).filter(Boolean), 'ws:', 'wss:'],
        formAction: ["'self'"],
        upgradeInsecureRequests: env.NODE_ENV === 'production' ? [] : null,
      },
    },
    referrerPolicy: { policy: 'strict-origin-when-cross-origin' },
  }));
  app.use(cors({ origin(origin, cb) { const allowed = env.CLIENT_URL.split(',').map((x) => x.trim()); if (!origin || allowed.includes(origin)) cb(null, true); else cb(new Error('Origin not allowed')); }, credentials: true }));
  app.use(compression());
  app.use(express.json({ limit: '2mb' }));
  app.use(express.urlencoded({ extended: true, limit: '2mb' }));
  app.use(cookieParser());
  if (env.NODE_ENV !== 'test') app.use(morgan(env.NODE_ENV === 'production' ? 'combined' : 'dev'));
  app.get('/api/health', (_req, res) => res.json({ success: true, service: 'secureasset-api', time: new Date().toISOString() }));
  const siteAssetDir = path.resolve(process.env.CMS_ASSET_DIR || 'storage/site-assets');
  fs.mkdirSync(siteAssetDir, { recursive: true });
  app.use('/site-assets', express.static(siteAssetDir, { maxAge: env.NODE_ENV === 'production' ? '365d' : '1h', immutable: env.NODE_ENV === 'production', dotfiles: 'deny', fallthrough: false }));
  if (env.LEGACY_PUBLIC_UPLOADS && env.NODE_ENV !== 'production') app.use('/uploads', express.static(path.resolve(env.UPLOAD_DIR), { maxAge: '1h', dotfiles: 'deny' }));
  app.use('/api/v1/auth', authRoutes);
  app.use('/api/v1/public', publicRoutes);
  app.use('/api/v1/site', siteRoutes);
  app.use('/api/v1/dashboard', dashboardRoutes);
  app.use('/api/v1/resources', resourceRoutes);
  app.use('/api/v1/uploads', uploadRoutes);
  app.use('/api/v1/attendance', attendanceRoutes);
  app.use('/api/v1/reports', reportRoutes);
  app.use('/api/v1/notifications', notificationRoutes);
  app.use('/api/v1/surveys', surveyRoutes);
  app.use('/api/v1/subscriptions', subscriptionRoutes);
  app.use('/api/v1/surveyor-subscriptions', surveyorSubscriptionRoutes);
  app.use('/api/v1/drive', driveRoutes);
  app.use('/api/v1/property-management', propertyManagementRoutes);
  app.use('/api/v1/public-drive', drivePublicRoutes);
  const dist = path.resolve('dist');
  if (env.NODE_ENV === 'production' && fs.existsSync(dist)) {
    app.use(express.static(dist));
    app.get('/{*splat}', (_req, res) => res.sendFile(path.join(dist, 'index.html')));
  }
  app.use(notFound);
  app.use(errorHandler);
  return app;
}
