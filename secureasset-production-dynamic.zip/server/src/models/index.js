import mongoose from 'mongoose';
import bcrypt from 'bcryptjs';

const { Schema, model, models } = mongoose;
const objectId = (ref, required = false) => ({ type: Schema.Types.ObjectId, ref, required });
const timestamps = { timestamps: true };

const UserSchema = new Schema({
  name: { type: String, required: true, trim: true, maxlength: 120 },
  email: { type: String, required: true, unique: true, lowercase: true, trim: true, index: true },
  phone: { type: String, trim: true, index: true },
  password: { type: String, required: true, minlength: 8, select: false },
  role: { type: String, enum: ['admin', 'manager', 'tenant', 'user', 'surveyor'], default: 'tenant', index: true },
  avatar: String,
  status: { type: String, enum: ['active', 'suspended', 'locked'], default: 'active', index: true },
  kycStatus: { type: String, enum: ['not_started', 'incomplete', 'submitted', 'under_review', 'changes_required', 'verified', 'rejected', 'expired', 'suspended', 'pending'], default: 'not_started', index: true },
  region: String,
  assignedProperties: [objectId('Property')],
  customPermissions: [String],
  landlordEnabled: { type: Boolean, default: false, index: true },
  landlordSubscriptionExpiresAt: Date,
  surveyorEnabled: { type: Boolean, default: false, index: true },
  surveyorSubscriptionExpiresAt: Date,
  activeMode: { type: String, enum: ['regular', 'landlord', 'surveyor'], default: 'regular' },
  lastLogin: Date,
  refreshTokens: [{ tokenHash: String, expiresAt: Date, device: String }],
  passwordResetTokenHash: { type: String, select: false },
  passwordResetExpiresAt: { type: Date, select: false },
  otpHash: { type: String, select: false },
  otpExpiresAt: { type: Date, select: false },
}, timestamps);
UserSchema.pre('save', async function next() {
  if (!this.isModified('password')) return;
  this.password = await bcrypt.hash(this.password, 12);
});
UserSchema.methods.comparePassword = function comparePassword(candidate) { return bcrypt.compare(candidate, this.password); };
UserSchema.methods.toJSON = function toJSON() {
  const obj = this.toObject();
  delete obj.password; delete obj.refreshTokens; delete obj.otpHash; delete obj.passwordResetTokenHash;
  return obj;
};

const PropertySchema = new Schema({
  title: { type: String, required: true, trim: true, index: 'text' },
  code: { type: String, unique: true, sparse: true, uppercase: true, trim: true },
  description: { type: String, default: '', index: 'text' },
  type: { type: String, required: true, trim: true, index: true },
  status: { type: String, enum: ['draft', 'pending_approval', 'available', 'partially_occupied', 'occupied', 'reserved', 'rented', 'sold', 'leased', 'maintenance', 'unavailable', 'inactive', 'archived'], default: 'draft', index: true },
  price: { type: Number, default: 0, min: 0 },
  listingType: { type: String, enum: ['rent', 'sale', 'lease'], default: 'rent', index: true },
  isSale: { type: Boolean, default: false },
  visibility: { type: String, enum: ['private', 'public'], default: 'private', index: true },
  publicationStatus: { type: String, enum: ['draft', 'published', 'archived'], default: 'draft', index: true },
  publishedAt: Date,
  requiresActiveSubscription: { type: Boolean, default: false, index: true },
  bedrooms: Number, bathrooms: Number, area: Number,
  roomCounts: { rooms: Number, balconies: Number, bathrooms: Number, toilets: Number, kitchens: Number, bedrooms: Number, diningRooms: Number, masterBedrooms: Number, livingRooms: Number },
  listingDetails: { securityDeposit: Number, maintenanceCharge: Number, negotiable: Boolean, furnishing: { type: String, enum: ['unfurnished', 'semi_furnished', 'fully_furnished'] }, parkingSpaces: Number, floor: String, totalFloors: Number, propertyAgeYears: Number, availableFrom: Date, possessionStatus: String, facing: String, petFriendly: Boolean },
  address: { line1: String, line2: String, city: { type: String, index: true }, state: String, country: { type: String, default: 'India' }, postalCode: String },
  location: { type: { type: String, enum: ['Point'], default: 'Point' }, coordinates: { type: [Number], default: [0, 0] } },
  images: [String], amenities: [String], documents: [objectId('Document')],
  owner: objectId('User'), manager: objectId('User'),
  totalUnits: { type: Number, default: 0 }, occupiedUnits: { type: Number, default: 0 },
  isVerified: { type: Boolean, default: false }, isFeatured: { type: Boolean, default: false },
  createdBy: objectId('User'), updatedBy: objectId('User'),
}, timestamps);

PropertySchema.add({
  referenceNumber: { type: String, unique: true, sparse: true, index: true },
  purpose: { type: String, enum: ['rent', 'sale', 'lease'], default: 'rent', index: true },
  customType: String,
  customAttributes: { type: Schema.Types.Mixed, default: {} },
  hierarchyMode: { type: String, enum: ['simple', 'building', 'apartment_building', 'pg_hostel', 'commercial', 'land'], default: 'simple' },
  pricing: {
    salePrice: Number, monthlyRent: Number, leaseAmount: Number, securityDeposit: Number,
    maintenanceCharge: Number, negotiable: Boolean, pricePerUnitArea: Number,
    additionalCharges: [{ label: String, amount: Number, recurring: Boolean }],
  },
  areas: {
    unit: { type: String, default: 'sqft' }, total: Number, carpet: Number, builtUp: Number,
    superBuiltUp: Number, plot: Number, garden: Number, parking: Number,
  },
  roomDetails: {
    totalApartments: Number, totalRooms: Number, bedrooms: Number, masterBedrooms: Number,
    bathrooms: Number, toilets: Number, kitchens: Number, livingRooms: Number, diningRooms: Number,
    balconies: Number, gardens: Number, swimmingPools: Number, parkingSpaces: Number,
    coveredParking: Number, openParking: Number, storeRooms: Number, utilityRooms: Number,
    servantRooms: Number, studyRooms: Number,
  },
  furnishing: {
    status: { type: String, enum: ['unfurnished', 'semi_furnished', 'fully_furnished'] },
    items: [String], notes: String,
  },
  ageDetails: {
    band: String, constructionYear: Number, renovationYear: Number, possessionDate: Date, availableFrom: Date,
  },
  map: {
    latitude: Number, longitude: Number, landmark: String, locality: String, district: String,
    nearbyPlaces: [{ name: String, distance: String, type: String }], approximateLatitude: Number, approximateLongitude: Number,
  },
  locationPrivacy: { type: String, enum: ['exact_public', 'approximate_public', 'after_application', 'after_visit_approval', 'selected_users'], default: 'approximate_public' },
  occupancyRules: {
    maxTotal: Number, maxAdults: Number, maxChildren: Number, maxPerRoom: Number,
    familyAllowed: { type: Boolean, default: true }, bachelorsAllowed: Boolean, studentsAllowed: Boolean,
    professionalsAllowed: Boolean, sharedOccupancyAllowed: Boolean, petsAllowed: Boolean,
    additionalOccupantsRequireApproval: { type: Boolean, default: true },
  },
  galleryCover: String,
  promotion: {
    featured: Boolean, topListing: Boolean, urgentType: { type: String, enum: ['none', 'urgent_sale', 'urgent_rent', 'immediate_possession', 'available_now', 'price_reduced'], default: 'none' },
    startsAt: Date, endsAt: Date,
  },
  metrics: { views: { type: Number, default: 0 }, clicks: { type: Number, default: 0 }, enquiries: { type: Number, default: 0 }, applications: { type: Number, default: 0 }, siteVisits: { type: Number, default: 0 }, conversions: { type: Number, default: 0 } },
  deletedAt: Date,
});
PropertySchema.index({ location: '2dsphere' });
PropertySchema.index({ visibility: 1, publicationStatus: 1, listingType: 1, status: 1, createdAt: -1 });

const UnitSchema = new Schema({
  property: { ...objectId('Property'), index: true },
  buildingName: String, floor: String,
  unitNumber: { type: String, required: true },
  type: String, bedrooms: Number, bathrooms: Number, area: Number,
  monthlyRent: { type: Number, default: 0 }, securityDeposit: { type: Number, default: 0 },
  status: { type: String, enum: ['vacant', 'occupied', 'reserved', 'maintenance', 'inactive'], default: 'vacant', index: true },
  amenities: [String], meterNumbers: { electricity: String, water: String },
  assignedTenant: objectId('User'),
  createdBy: objectId('User'), updatedBy: objectId('User'),
}, timestamps);
UnitSchema.index({ property: 1, unitNumber: 1 }, { unique: true });

const TenantSchema = new Schema({
  user: { ...objectId('User', true), index: true },
  property: { ...objectId('Property'), index: true },
  unit: objectId('Unit'),
  status: { type: String, enum: ['applicant', 'active', 'notice', 'moved_out', 'rejected'], default: 'applicant', index: true },
  occupants: [{ name: String, relation: String, phone: String, authorised: Boolean }],
  emergencyContact: { name: String, phone: String, relation: String },
  moveInDate: Date, moveOutDate: Date,
  documents: [objectId('Document')],
  createdBy: objectId('User'), updatedBy: objectId('User'),
}, timestamps);

const LeaseSchema = new Schema({
  leaseNumber: { type: String, unique: true, sparse: true },
  property: { ...objectId('Property'), index: true }, unit: objectId('Unit'),
  tenant: { ...objectId('User', true), index: true },
  startDate: { type: Date, required: true }, endDate: { type: Date, required: true, index: true },
  monthlyRent: { type: Number, required: true }, securityDeposit: Number,
  escalationPercent: Number, paymentDueDay: { type: Number, default: 1 },
  status: { type: String, enum: ['draft', 'pending_approval', 'active', 'expiring', 'expired', 'terminated', 'renewed'], default: 'draft', index: true },
  signature: { tenantSignedAt: Date, managerSignedAt: Date, tenantSignatureUrl: String, managerSignatureUrl: String },
  documents: [objectId('Document')], clauses: [String],
  createdBy: objectId('User'), updatedBy: objectId('User'),
}, timestamps);

const SurveySchema = new Schema({
  surveyNumber: { type: String, unique: true, sparse: true }, title: { type: String, required: true },
  property: { ...objectId('Property'), index: true }, unit: objectId('Unit'),
  surveyor: { ...objectId('User'), index: true }, assignedBy: objectId('User'),
  priority: { type: String, enum: ['low', 'medium', 'high', 'urgent'], default: 'medium' },
  deadline: Date, startedAt: Date, submittedAt: Date, approvedAt: Date,
  status: { type: String, enum: ['draft', 'assigned', 'in_progress', 'submitted', 'returned', 'approved', 'rejected', 'overdue'], default: 'assigned', index: true },
  template: { name: String, version: String }, responses: Schema.Types.Mixed,
  gps: { lat: Number, lng: Number, accuracy: Number, capturedAt: Date, verified: Boolean },
  photos: [{ url: String, caption: String, lat: Number, lng: Number, capturedAt: Date, watermark: String }],
  signatureUrl: String, notes: String,
  revisions: [{ version: Number, status: String, comment: String, changedBy: objectId('User'), changedAt: { type: Date, default: Date.now } }],
  offlineId: { type: String, sparse: true, index: true }, syncStatus: { type: String, enum: ['synced', 'pending', 'failed'], default: 'synced' },
  createdBy: objectId('User'), updatedBy: objectId('User'),
}, timestamps);

const ApplicationSchema = new Schema({
  applicationNumber: { type: String, unique: true, sparse: true },
  applicant: { ...objectId('User', true), index: true }, landlord: { ...objectId('User'), index: true }, property: { ...objectId('Property'), index: true }, unit: objectId('Unit'),
  step: { type: Number, min: 1, max: 9, default: 1 },
  status: { type: String, enum: ['draft', 'submitted', 'under_review', 'shortlisted', 'interview_requested', 'interview_scheduled', 'site_visit_scheduled', 'additional_documents_requested', 'documents_pending', 'approved', 'rejected', 'waiting_list', 'withdrawn', 'agreement_pending', 'deposit_pending', 'completed'], default: 'draft', index: true },
  personal: Schema.Types.Mixed, employment: Schema.Types.Mixed, identity: Schema.Types.Mixed,
  documents: [objectId('Document')], feeAmount: Number, paymentStatus: { type: String, enum: ['pending', 'paid', 'waived'], default: 'pending' },
  submittedAt: Date, reviewedBy: objectId('User'), remarks: String,
  createdBy: objectId('User'), updatedBy: objectId('User'),
}, timestamps);


ApplicationSchema.add({
  targetSpace: objectId('PropertySpace'),
  occupantSummary: { total: Number, adults: Number, children: Number, seniorCitizens: Number, male: Number, female: Number, familyStatus: String },
  occupantIds: [objectId('Occupant')],
  moveInDate: Date, expectedStayMonths: Number, monthlyIncome: Number, rentalBudget: Number,
  vehicles: [{ type: String, registration: String }], pets: [{ type: String, count: Number }], references: [{ name: String, phone: String, relation: String }],
  messageToLandlord: String, interviewScore: Number, landlordNotes: String, closedReason: String,
});

const PaymentSchema = new Schema({
  invoiceNumber: { type: String, unique: true, sparse: true },
  payer: { ...objectId('User', true), index: true }, payee: { ...objectId('User'), index: true }, tenant: objectId('Tenant'),
  surveyProject: { ...objectId('SurveyProject'), index: true }, surveyQuotation: objectId('SurveyQuotation'),
  property: { ...objectId('Property'), index: true }, unit: objectId('Unit'), lease: objectId('Lease'), application: objectId('Application'),
  type: { type: String, enum: ['rent', 'deposit', 'application_fee', 'landlord_subscription', 'surveyor_subscription', 'survey_advance', 'survey_milestone', 'survey_final', 'surveyor_payout', 'platform_commission', 'maintenance', 'penalty', 'refund', 'other'], default: 'rent' },
  amount: { type: Number, required: true, min: 0 }, paidAmount: { type: Number, default: 0, min: 0 },
  status: { type: String, enum: ['draft', 'pending', 'paid', 'partial', 'overdue', 'failed', 'refunded', 'waived'], default: 'pending', index: true },
  dueDate: { type: Date, index: true }, paidAt: Date,
  method: { type: String, enum: ['upi', 'card', 'bank_transfer', 'cash', 'cheque', 'gateway', 'offline'], default: 'offline' },
  transactionId: String, gateway: Schema.Types.Mixed, proofUrl: String, notes: String, taxAmount: Number, discountAmount: Number, travelAmount: Number, platformCommission: Number,
  createdBy: objectId('User'), updatedBy: objectId('User'),
}, timestamps);

const ComplaintSchema = new Schema({
  complaintNumber: { type: String, unique: true, sparse: true },
  title: { type: String, required: true, index: 'text' }, description: { type: String, required: true, index: 'text' },
  raisedBy: { ...objectId('User', true), index: true }, property: { ...objectId('Property'), index: true }, unit: objectId('Unit'),
  category: { type: String, default: 'maintenance' }, priority: { type: String, enum: ['low', 'medium', 'high', 'urgent'], default: 'medium' },
  status: { type: String, enum: ['open', 'assigned', 'in_progress', 'awaiting_approval', 'resolved', 'closed', 'reopened'], default: 'open', index: true },
  assignedTo: objectId('User'), vendor: { name: String, phone: String, email: String },
  estimatedCost: Number, approvedCost: Number, slaDueAt: Date,
  attachments: [String], beforePhotos: [String], afterPhotos: [String],
  timeline: [{ status: String, note: String, user: objectId('User'), at: { type: Date, default: Date.now } }],
  tenantConfirmedAt: Date, resolutionNote: String,
  createdBy: objectId('User'), updatedBy: objectId('User'),
}, timestamps);

const ApprovalSchema = new Schema({
  title: { type: String, required: true }, type: { type: String, required: true, index: true },
  requester: { ...objectId('User', true), index: true }, property: objectId('Property'), amount: Number,
  priority: { type: String, enum: ['low', 'medium', 'high', 'urgent'], default: 'medium' },
  status: { type: String, enum: ['pending', 'approved', 'rejected', 'returned', 'escalated', 'cancelled'], default: 'pending', index: true },
  currentStage: { type: Number, default: 1 }, stages: [{ name: String, approverRole: String, approver: objectId('User'), status: String, comment: String, actedAt: Date }],
  referenceModel: String, referenceId: Schema.Types.ObjectId,
  documents: [objectId('Document')], comments: [{ user: objectId('User'), message: String, at: { type: Date, default: Date.now } }],
  createdBy: objectId('User'), updatedBy: objectId('User'),
}, timestamps);

const NotificationSchema = new Schema({
  user: { ...objectId('User', true), index: true }, title: String, message: String,
  category: { type: String, enum: ['payment', 'survey', 'complaint', 'lease', 'maintenance', 'system', 'message'], default: 'system' },
  readAt: Date, actionUrl: String, metadata: Schema.Types.Mixed,
}, timestamps);

const MessageSchema = new Schema({
  conversationId: { type: String, required: true, index: true },
  sender: { ...objectId('User', true), index: true }, recipients: [{ ...objectId('User'), index: true }],
  body: String, attachments: [String], readBy: [{ user: objectId('User'), readAt: Date }],
  reference: { type: String, id: Schema.Types.ObjectId, label: String },
}, timestamps);

const DocumentSchema = new Schema({
  name: { type: String, required: true }, type: { type: String, default: 'other' }, url: { type: String, required: true }, mimeType: String,
  sizeBytes: Number, owner: { ...objectId('User', true), index: true }, property: objectId('Property'),
  visibility: { type: String, enum: ['private', 'property', 'public'], default: 'private' }, checksum: String,
  uploadedBy: objectId('User'),
}, timestamps);

const AttendanceSchema = new Schema({
  user: { ...objectId('User', true), index: true }, date: { type: String, required: true, index: true },
  checkInAt: Date, checkOutAt: Date, checkInGps: { lat: Number, lng: Number, accuracy: Number }, checkOutGps: { lat: Number, lng: Number, accuracy: Number },
  status: { type: String, enum: ['present', 'late', 'absent', 'field'], default: 'field' }, notes: String,
}, timestamps);
AttendanceSchema.index({ user: 1, date: 1 }, { unique: true });

const SubscriptionSchema = new Schema({
  user: { ...objectId('User', true), index: true },
  plan: { type: String, enum: ['starter', 'professional', 'business', 'enterprise'], required: true, index: true },
  billingCycle: { type: String, enum: ['monthly', 'yearly'], default: 'monthly' },
  amount: { type: Number, required: true, min: 0 }, currency: { type: String, default: 'INR' },
  status: { type: String, enum: ['pending', 'active', 'expired', 'cancelled', 'failed'], default: 'pending', index: true },
  startsAt: Date, expiresAt: { type: Date, index: true }, cancelledAt: Date,
  limits: { properties: { type: Number, default: 3 }, buildings: { type: Number, default: 1 }, apartments: { type: Number, default: 5 }, rooms: { type: Number, default: 20 }, beds: { type: Number, default: 20 }, publicListings: { type: Number, default: 3 }, activeTenants: { type: Number, default: 20 }, storageMB: { type: Number, default: 5120 }, teamMembers: { type: Number, default: 1 }, rentAutomation: { type: Boolean, default: false }, advancedReports: { type: Boolean, default: false }, promotions: { type: Boolean, default: false }, apiAccess: { type: Boolean, default: false } },
  payment: { method: String, transactionId: String, gateway: String, paidAt: Date, metadata: Schema.Types.Mixed },
  createdBy: objectId('User'), updatedBy: objectId('User'),
}, timestamps);
SubscriptionSchema.index({ user: 1, status: 1, expiresAt: -1 });

const AuditLogSchema = new Schema({
  user: objectId('User'), role: String, action: String, module: String, recordId: Schema.Types.ObjectId,
  ip: String, device: String, previousValue: Schema.Types.Mixed, updatedValue: Schema.Types.Mixed,
}, { timestamps: { createdAt: true, updatedAt: false } });
AuditLogSchema.index({ createdAt: -1, module: 1, user: 1 });

export const User = models.User || model('User', UserSchema);
export const Property = models.Property || model('Property', PropertySchema);
export const Unit = models.Unit || model('Unit', UnitSchema);
export const Tenant = models.Tenant || model('Tenant', TenantSchema);
export const Lease = models.Lease || model('Lease', LeaseSchema);
export const Survey = models.Survey || model('Survey', SurveySchema);
export const Application = models.Application || model('Application', ApplicationSchema);
export const Payment = models.Payment || model('Payment', PaymentSchema);
export const Complaint = models.Complaint || model('Complaint', ComplaintSchema);
export const Approval = models.Approval || model('Approval', ApprovalSchema);
export const Notification = models.Notification || model('Notification', NotificationSchema);
export const Message = models.Message || model('Message', MessageSchema);
export const Document = models.Document || model('Document', DocumentSchema);
export const Attendance = models.Attendance || model('Attendance', AttendanceSchema);
export const Subscription = models.Subscription || model('Subscription', SubscriptionSchema);
export const AuditLog = models.AuditLog || model('AuditLog', AuditLogSchema);

export * from './surveyor.js';

export * from './drive.js';

export {
  SiteSetting, SeoPage, HomeCarousel, HomeSection, LandlordPlan, PropertyTypeConfig, AreaUnit,
  PropertySpace, PropertyMedia, TenantProfile, TenantKyc, Occupant, TenantInterview, PropertyVisit,
  Tenancy, RentalInvoice, UtilityReading, ReminderRule, PropertyPromotion, SiteEnquiry,
} from './propertyManagement.js';
