import bcrypt from 'bcryptjs';
import { z } from 'zod';
import { User, AuditLog } from '../models/index.js';
import { ApiError } from '../utils/apiError.js';
import { asyncHandler } from '../utils/asyncHandler.js';
import { signAccessToken, signRefreshToken, verifyRefreshToken, hashToken, randomToken } from '../utils/tokens.js';
import { env } from '../config/env.js';
import { ensurePersonalDrive } from '../services/driveService.js';

const credentialsSchema = z.object({ email: z.string().email(), password: z.string().min(8) });
const registerSchema = credentialsSchema.extend({ name: z.string().min(2).max(120), phone: z.string().optional() });

function safeUser(user) { return user.toJSON ? user.toJSON() : user; }

async function issueSession(user, req, res) {
  const accessToken = signAccessToken(user);
  const refreshToken = signRefreshToken(user);
  user.refreshTokens = (user.refreshTokens || []).filter((item) => item.expiresAt > new Date()).slice(-4);
  user.refreshTokens.push({ tokenHash: hashToken(refreshToken), expiresAt: new Date(Date.now() + env.REFRESH_TOKEN_TTL_DAYS * 86400000), device: req.headers['user-agent'] });
  user.lastLogin = new Date();
  await user.save({ validateModifiedOnly: true });
  res.cookie('sa_refresh', refreshToken, { httpOnly: true, secure: env.NODE_ENV === 'production', sameSite: 'lax', maxAge: env.REFRESH_TOKEN_TTL_DAYS * 86400000, path: '/api/v1/auth' });
  return { accessToken, user: safeUser(user), expiresIn: env.ACCESS_TOKEN_TTL };
}

export const register = asyncHandler(async (req, res) => {
  const parsed = registerSchema.safeParse(req.body);
  if (!parsed.success) throw new ApiError(422, 'Invalid registration data', parsed.error.flatten());
  if (await User.exists({ email: parsed.data.email.toLowerCase() })) throw new ApiError(409, 'An account already exists with this email');
  const user = await User.create({ ...parsed.data, role: 'tenant' });
  await ensurePersonalDrive(user._id);
  const session = await issueSession(user, req, res);
  res.status(201).json({ success: true, data: session });
});

export const login = asyncHandler(async (req, res) => {
  const parsed = credentialsSchema.safeParse(req.body);
  if (!parsed.success) throw new ApiError(422, 'Enter a valid email and password');
  const user = await User.findOne({ email: parsed.data.email.toLowerCase() }).select('+password +refreshTokens');
  if (!user || !(await user.comparePassword(parsed.data.password))) throw new ApiError(401, 'Invalid email or password');
  if (user.status !== 'active') throw new ApiError(403, `Account is ${user.status}`);
  const session = await issueSession(user, req, res);
  await AuditLog.create({ user: user._id, role: user.role, action: 'login', module: 'auth', ip: req.ip, device: req.headers['user-agent'] });
  res.json({ success: true, data: session });
});

export const refresh = asyncHandler(async (req, res) => {
  const token = req.cookies.sa_refresh;
  if (!token) throw new ApiError(401, 'Refresh token missing');
  let payload;
  try { payload = verifyRefreshToken(token); } catch { throw new ApiError(401, 'Refresh token is invalid or expired'); }
  const user = await User.findById(payload.sub).select('+refreshTokens');
  if (!user || !user.refreshTokens.some((item) => item.tokenHash === hashToken(token) && item.expiresAt > new Date())) throw new ApiError(401, 'Refresh session is no longer valid');
  user.refreshTokens = user.refreshTokens.filter((item) => item.tokenHash !== hashToken(token));
  const session = await issueSession(user, req, res);
  res.json({ success: true, data: session });
});

export const logout = asyncHandler(async (req, res) => {
  const token = req.cookies.sa_refresh;
  if (token && req.user) {
    const user = await User.findById(req.user._id).select('+refreshTokens');
    if (user) { user.refreshTokens = user.refreshTokens.filter((item) => item.tokenHash !== hashToken(token)); await user.save({ validateModifiedOnly: true }); }
  }
  res.clearCookie('sa_refresh', { path: '/api/v1/auth' });
  res.json({ success: true, message: 'Logged out' });
});

export const me = asyncHandler(async (req, res) => res.json({ success: true, data: safeUser(req.user) }));

export const sendOtp = asyncHandler(async (req, res) => {
  const identifier = String(req.body.email || req.body.phone || '').trim();
  if (!identifier) throw new ApiError(422, 'Email or phone is required');
  const user = await User.findOne(identifier.includes('@') ? { email: identifier.toLowerCase() } : { phone: identifier }).select('+otpHash +otpExpiresAt');
  if (!user) return res.json({ success: true, message: 'If the account exists, an OTP has been sent' });
  const otp = env.NODE_ENV === 'production' ? String(Math.floor(100000 + Math.random() * 900000)) : env.DEMO_OTP;
  user.otpHash = await bcrypt.hash(otp, 10); user.otpExpiresAt = new Date(Date.now() + 10 * 60 * 1000); await user.save({ validateModifiedOnly: true });
  // Integrate an SMS/email provider here; credentials remain server-side.
  res.json({ success: true, message: 'OTP generated', ...(env.NODE_ENV !== 'production' && { developmentOtp: otp }) });
});

export const verifyOtp = asyncHandler(async (req, res) => {
  const identifier = String(req.body.email || req.body.phone || '').trim();
  const otp = String(req.body.otp || '');
  const user = await User.findOne(identifier.includes('@') ? { email: identifier.toLowerCase() } : { phone: identifier }).select('+otpHash +otpExpiresAt +refreshTokens');
  if (!user || !user.otpHash || user.otpExpiresAt < new Date() || !(await bcrypt.compare(otp, user.otpHash))) throw new ApiError(401, 'OTP is invalid or expired');
  user.otpHash = undefined; user.otpExpiresAt = undefined;
  const session = await issueSession(user, req, res);
  res.json({ success: true, data: session });
});

export const forgotPassword = asyncHandler(async (req, res) => {
  const email = String(req.body.email || '').toLowerCase();
  const user = await User.findOne({ email }).select('+passwordResetTokenHash +passwordResetExpiresAt');
  let resetToken;
  if (user) {
    resetToken = randomToken(); user.passwordResetTokenHash = hashToken(resetToken); user.passwordResetExpiresAt = new Date(Date.now() + 30 * 60 * 1000); await user.save({ validateModifiedOnly: true });
  }
  res.json({ success: true, message: 'If the account exists, password reset instructions have been issued', ...(env.NODE_ENV !== 'production' && resetToken && { resetToken }) });
});

export const resetPassword = asyncHandler(async (req, res) => {
  const tokenHash = hashToken(String(req.body.token || ''));
  const password = String(req.body.password || '');
  if (password.length < 8) throw new ApiError(422, 'Password must contain at least 8 characters');
  const user = await User.findOne({ passwordResetTokenHash: tokenHash, passwordResetExpiresAt: { $gt: new Date() } }).select('+password +passwordResetTokenHash +passwordResetExpiresAt +refreshTokens');
  if (!user) throw new ApiError(400, 'Reset token is invalid or expired');
  user.password = password; user.passwordResetTokenHash = undefined; user.passwordResetExpiresAt = undefined; user.refreshTokens = [];
  await user.save();
  res.json({ success: true, message: 'Password reset successfully' });
});
