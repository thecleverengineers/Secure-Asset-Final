import crypto from 'crypto';
import fs from 'fs/promises';
import path from 'path';
import { asyncHandler } from '../utils/asyncHandler.js';
import { ApiError } from '../utils/apiError.js';
import { AuditLog } from '../models/index.js';

const allowed = new Map([
  ['image/jpeg', '.jpg'], ['image/png', '.png'], ['image/webp', '.webp'], ['image/gif', '.gif'], ['image/svg+xml', '.svg'],
]);
function validImage(buffer, mime) {
  if (mime === 'image/jpeg') return buffer[0] === 0xff && buffer[1] === 0xd8;
  if (mime === 'image/png') return buffer.subarray(0, 8).equals(Buffer.from([137,80,78,71,13,10,26,10]));
  if (mime === 'image/webp') return buffer.subarray(0, 4).toString() === 'RIFF' && buffer.subarray(8, 12).toString() === 'WEBP';
  if (mime === 'image/gif') return ['GIF87a', 'GIF89a'].includes(buffer.subarray(0, 6).toString());
  if (mime === 'image/svg+xml') {
    const text = buffer.toString('utf8', 0, Math.min(buffer.length, 20000)).toLowerCase();
    return text.includes('<svg') && !/<script|javascript:|onload\s*=|onerror\s*=/.test(text);
  }
  return false;
}

export const uploadSiteAsset = asyncHandler(async (req, res) => {
  if (req.user.role !== 'admin') throw new ApiError(403, 'Administrator access required');
  if (!req.file) throw new ApiError(422, 'Choose an image to upload');
  const ext = allowed.get(req.file.mimetype);
  if (!ext || !validImage(req.file.buffer, req.file.mimetype)) throw new ApiError(422, 'Unsupported or invalid image');
  const dir = path.resolve(process.env.CMS_ASSET_DIR || 'storage/site-assets');
  await fs.mkdir(dir, { recursive: true });
  const filename = `${Date.now()}-${crypto.randomBytes(12).toString('hex')}${ext}`;
  await fs.writeFile(path.join(dir, filename), req.file.buffer, { flag: 'wx', mode: 0o640 });
  const url = `/site-assets/${filename}`;
  await AuditLog.create({ user: req.user._id, role: req.user.role, action: 'upload', module: 'site-assets', updatedValue: { url, mimeType: req.file.mimetype, size: req.file.size }, ip: req.ip, device: req.get('user-agent') });
  res.status(201).json({ success: true, data: { url, filename, mimeType: req.file.mimetype, size: req.file.size } });
});
