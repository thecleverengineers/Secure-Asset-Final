import { Notification } from '../models/index.js';
import { asyncHandler } from '../utils/asyncHandler.js';

export const unreadCount = asyncHandler(async (req, res) => {
  const count = await Notification.countDocuments({ user: req.user._id, readAt: null });
  res.json({ success: true, data: { count } });
});
export const markAllRead = asyncHandler(async (req, res) => {
  await Notification.updateMany({ user: req.user._id, readAt: null }, { $set: { readAt: new Date() } });
  res.json({ success: true, message: 'Notifications marked as read' });
});
