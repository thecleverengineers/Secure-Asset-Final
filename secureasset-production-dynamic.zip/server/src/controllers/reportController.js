import { resources } from '../services/resources.js';
import { buildScope } from '../services/scope.js';
import { asyncHandler } from '../utils/asyncHandler.js';
import { ApiError } from '../utils/apiError.js';

function csvCell(value) {
  if (value === null || value === undefined) return '';
  const text = typeof value === 'object' ? JSON.stringify(value) : String(value);
  return `"${text.replaceAll('"', '""')}"`;
}

export const exportCsv = asyncHandler(async (req, res) => {
  const config = resources[req.params.resource];
  if (!config || !config.readRoles.includes(req.user.role)) throw new ApiError(403, 'Report is unavailable');
  const docs = await config.model.find(buildScope(req.user, req.params.resource)).sort('-createdAt').limit(5000).lean();
  const fields = req.query.fields ? String(req.query.fields).split(',') : [...new Set(docs.flatMap((doc) => Object.keys(doc)))].slice(0, 30);
  const rows = [fields.map(csvCell).join(','), ...docs.map((doc) => fields.map((field) => csvCell(doc[field])).join(','))];
  res.setHeader('Content-Type', 'text/csv; charset=utf-8');
  res.setHeader('Content-Disposition', `attachment; filename="${req.params.resource}-${new Date().toISOString().slice(0, 10)}.csv"`);
  res.send(`\uFEFF${rows.join('\n')}`);
});
