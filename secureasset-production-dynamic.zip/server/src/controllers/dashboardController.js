import { Property, Unit, Tenant, Lease, Survey, Application, Payment, Complaint, Approval, User, AuditLog } from '../models/index.js';
import { assignedPropertyIds } from '../services/scope.js';
import { asyncHandler } from '../utils/asyncHandler.js';

function filtersFor(user) {
  if (user.role === 'admin') return { property: {}, user: {} };
  if (user.role === 'manager') return { property: { property: { $in: assignedPropertyIds(user) } }, user: {} };
  if (user.role === 'tenant') return { property: {}, user: { tenant: user._id, payer: user._id, raisedBy: user._id } };
  if (user.role === 'user') return { property: {}, user: { applicant: user._id, payer: user._id, raisedBy: user._id } };
  return { property: {}, user: { surveyor: user._id } };
}

function propertyMatch(user, field = 'property') {
  if (user.role === 'manager') return { [field]: { $in: assignedPropertyIds(user) } };
  return {};
}

export const overview = asyncHandler(async (req, res) => {
  const user = req.user;
  const now = new Date();
  const monthStart = new Date(now.getFullYear(), now.getMonth(), 1);
  const monthEnd = new Date(now.getFullYear(), now.getMonth() + 1, 1);
  const leaseExpiry = new Date(now.getTime() + 60 * 86400000);
  const propertyIds = assignedPropertyIds(user);

  const propertyFilter = user.role === 'manager' ? { _id: { $in: propertyIds } } : {};
  const unitFilter = propertyMatch(user);
  const tenantFilter = propertyMatch(user);
  const leaseFilter = user.role === 'tenant' ? { tenant: user._id } : propertyMatch(user);
  const surveyFilter = user.role === 'surveyor' ? { surveyor: user._id } : propertyMatch(user);
  const applicationFilter = user.role === 'user' ? { applicant: user._id } : propertyMatch(user);
  const paymentFilter = ['tenant', 'user'].includes(user.role) ? { payer: user._id } : propertyMatch(user);
  const complaintFilter = ['tenant', 'user'].includes(user.role) ? { raisedBy: user._id } : propertyMatch(user);
  const approvalFilter = ['tenant', 'user', 'surveyor'].includes(user.role) ? { requester: user._id } : user.role === 'manager' ? { $or: [{ property: { $in: propertyIds } }, { requester: user._id }] } : {};

  const [
    totalProperties, totalUnits, occupiedUnits, totalTenants, activeUsers,
    pendingApplications, pendingSurveys, monthlyRevenueResult, outstandingResult,
    openComplaints, expiringLeases, pendingApprovals,
    surveyGroups, complaintGroups, recentActivities,
  ] = await Promise.all([
    Property.countDocuments(propertyFilter),
    Unit.countDocuments(unitFilter),
    Unit.countDocuments({ ...unitFilter, status: 'occupied' }),
    Tenant.countDocuments({ ...tenantFilter, status: 'active' }),
    user.role === 'admin' ? User.countDocuments({ status: 'active' }) : Promise.resolve(0),
    Application.countDocuments({ ...applicationFilter, status: { $in: ['submitted', 'under_review', 'documents_pending'] } }),
    Survey.countDocuments({ ...surveyFilter, status: { $in: ['assigned', 'in_progress', 'submitted', 'returned', 'overdue'] } }),
    Payment.aggregate([{ $match: { ...paymentFilter, status: 'paid', paidAt: { $gte: monthStart, $lt: monthEnd } } }, { $group: { _id: null, total: { $sum: '$paidAmount' } } }]),
    Payment.aggregate([{ $match: { ...paymentFilter, status: { $in: ['pending', 'partial', 'overdue'] } } }, { $group: { _id: null, total: { $sum: { $subtract: ['$amount', '$paidAmount'] } } } }]),
    Complaint.countDocuments({ ...complaintFilter, status: { $nin: ['closed', 'resolved'] } }),
    Lease.countDocuments({ ...leaseFilter, status: { $in: ['active', 'expiring'] }, endDate: { $gte: now, $lte: leaseExpiry } }),
    Approval.countDocuments({ ...approvalFilter, status: 'pending' }),
    Survey.aggregate([{ $match: surveyFilter }, { $group: { _id: '$status', value: { $sum: 1 } } }, { $sort: { value: -1 } }]),
    Complaint.aggregate([{ $match: complaintFilter }, { $group: { _id: '$status', value: { $sum: 1 } } }, { $sort: { value: -1 } }]),
    AuditLog.find(user.role === 'admin' ? {} : { user: user._id }).sort('-createdAt').limit(8).populate('user', 'name role').lean(),
  ]);

  const revenueTrend = [];
  for (let offset = 5; offset >= 0; offset -= 1) {
    const start = new Date(now.getFullYear(), now.getMonth() - offset, 1);
    const end = new Date(now.getFullYear(), now.getMonth() - offset + 1, 1);
    const result = await Payment.aggregate([{ $match: { ...paymentFilter, status: 'paid', paidAt: { $gte: start, $lt: end } } }, { $group: { _id: null, amount: { $sum: '$paidAmount' } } }]);
    revenueTrend.push({ month: start.toLocaleString('en', { month: 'short' }), amount: result[0]?.amount || 0 });
  }

  const roleSpecific = {};
  if (user.role === 'surveyor') {
    roleSpecific.todayAssignments = await Survey.countDocuments({ surveyor: user._id, deadline: { $gte: new Date(now.toDateString()), $lt: new Date(new Date(now.toDateString()).getTime() + 86400000) } });
    roleSpecific.completedSurveys = await Survey.countDocuments({ surveyor: user._id, status: 'approved' });
  }
  if (user.role === 'tenant') {
    roleSpecific.nextPayment = await Payment.findOne({ payer: user._id, status: { $in: ['pending', 'partial', 'overdue'] } }).sort('dueDate').lean();
    roleSpecific.activeLease = await Lease.findOne({ tenant: user._id, status: { $in: ['active', 'expiring'] } }).populate('property unit').lean();
  }
  if (user.role === 'user') {
    roleSpecific.latestApplication = await Application.findOne({ applicant: user._id }).sort('-createdAt').populate('property').lean();
  }

  res.json({
    success: true,
    data: {
      kpis: { totalProperties, totalUnits, occupiedUnits, vacantUnits: Math.max(totalUnits - occupiedUnits, 0), totalTenants, activeUsers, pendingApplications, pendingSurveys, monthlyRentCollection: monthlyRevenueResult[0]?.total || 0, outstandingDues: outstandingResult[0]?.total || 0, openComplaints, expiringLeases, pendingApprovals },
      occupancyRate: totalUnits ? Math.round((occupiedUnits / totalUnits) * 100) : 0,
      revenueTrend,
      surveyStatus: surveyGroups.map((item) => ({ name: item._id, value: item.value })),
      complaintStatus: complaintGroups.map((item) => ({ name: item._id, value: item.value })),
      recentActivities,
      ...roleSpecific,
    },
  });
});
