import { Property, PropertySpace, PropertyMedia, Subscription } from '../models/index.js';
import { asyncHandler } from '../utils/asyncHandler.js';
import { ApiError } from '../utils/apiError.js';

function formatProperty(doc) {
  const price = Number(doc.pricing?.salePrice || doc.pricing?.monthlyRent || doc.pricing?.leaseAmount || doc.price || 0);
  return {
    ...doc,
    listingKind: 'property', propertyId: doc._id, spaceId: null,
    price, isSale: (doc.purpose || doc.listingType) === 'sale', listingType: doc.purpose || doc.listingType || 'rent',
    location: doc.address?.line1 || '', city: doc.address?.city || '', country: doc.address?.country || 'India',
    bedrooms: doc.roomDetails?.bedrooms ?? doc.roomCounts?.bedrooms ?? doc.bedrooms ?? null,
    bathrooms: doc.roomDetails?.bathrooms ?? doc.roomCounts?.bathrooms ?? doc.bathrooms ?? null,
    area: Number(doc.areas?.total?.value || doc.area || 0), areaUnit: doc.areas?.total?.unit || 'sqft',
    images: [doc.galleryCover, ...(doc.images || [])].filter(Boolean),
    landlordId: doc.owner?._id || doc.owner || null, tenantId: null,
    isFeatured: Boolean(doc.promotion?.featured || doc.isFeatured),
    urgentType: doc.promotion?.urgentType || 'none',
  };
}
function formatSpace(doc) {
  const property = doc.property || {};
  return {
    ...doc,
    _id: doc._id, listingKind: 'space', propertyId: property._id, spaceId: doc._id,
    title: `${doc.name} · ${property.title || 'Property'}`,
    description: doc.description || property.description || '',
    type: doc.level, status: doc.status, price: Number(doc.price || 0),
    listingType: doc.purpose || 'rent', isSale: doc.purpose === 'sale',
    address: property.address, location: property.address?.line1 || '', city: property.address?.city || '', country: property.address?.country || 'India',
    bedrooms: doc.roomDetails?.bedrooms ?? (doc.level === 'room' ? 1 : null),
    bathrooms: doc.roomDetails?.bathrooms ?? null,
    area: Number(doc.area?.value || 0), areaUnit: doc.area?.unit || 'sqft',
    images: [doc.coverImage, property.galleryCover, ...(property.images || [])].filter(Boolean),
    amenities: [...new Set([...(doc.amenities || []), ...(property.amenities || [])])],
    owner: property.owner || doc.owner, landlordId: doc.owner?._id || doc.owner || null,
    isVerified: property.isVerified, isFeatured: Boolean(doc.promotion?.featured || property.promotion?.featured),
    urgentType: doc.promotion?.urgentType || property.promotion?.urgentType || 'none',
    createdAt: doc.createdAt, updatedAt: doc.updatedAt,
  };
}
async function activeLandlordIds() {
  return Subscription.distinct('user', { status: 'active', expiresAt: { $gt: new Date() } });
}
async function publicFilter(extra = {}) {
  const activeOwnerIds = await activeLandlordIds();
  return { visibility: 'public', publicationStatus: 'published', status: { $in: ['available', 'partially_occupied'] }, $and: [{ $or: [{ requiresActiveSubscription: false }, { owner: { $in: activeOwnerIds } }] }], ...extra };
}
export const listPublicProperties = asyncHandler(async (req, res) => {
  const page = Math.max(Number(req.query.page || 1), 1); const limit = Math.min(Number(req.query.limit || 12), 50);
  const activeOwnerIds = await activeLandlordIds();
  const propertyFilter = await publicFilter();
  const listingType = String(req.query.listingType || (req.query.isSale === 'true' ? 'sale' : req.query.isSale === 'false' ? 'rent' : ''));
  if (req.query.type && req.query.type !== 'all') propertyFilter.type = req.query.type;
  if (req.query.city) propertyFilter['address.city'] = new RegExp(String(req.query.city), 'i');
  if (['rent', 'sale', 'lease'].includes(listingType)) propertyFilter.$or = [{ purpose: listingType }, { listingType }];
  if (req.query.minPrice || req.query.maxPrice) propertyFilter.price = { ...(req.query.minPrice && { $gte: Number(req.query.minPrice) }), ...(req.query.maxPrice && { $lte: Number(req.query.maxPrice) }) };
  if (req.query.search) propertyFilter.$text = { $search: String(req.query.search) };

  const basePropertyFilter = { visibility: 'public', publicationStatus: 'published', status: { $in: ['available', 'partially_occupied'] }, owner: { $in: activeOwnerIds }, deletedAt: null };
  if (req.query.city) basePropertyFilter['address.city'] = new RegExp(String(req.query.city), 'i');
  if (req.query.search) basePropertyFilter.$text = { $search: String(req.query.search) };
  const matchingPropertyIds = await Property.distinct('_id', basePropertyFilter);
  const spaceFilter = {
    property: { $in: matchingPropertyIds }, owner: { $in: activeOwnerIds }, visibility: 'public', publicationStatus: 'published',
    status: 'available', rentable: listingType !== 'sale', ...(listingType === 'sale' ? { sellable: true } : {}), deletedAt: null,
  };
  if (['rent', 'sale', 'lease'].includes(listingType)) spaceFilter.purpose = listingType;
  if (req.query.level && req.query.level !== 'all') spaceFilter.level = req.query.level;
  if (req.query.type && req.query.type !== 'all') spaceFilter.level = req.query.type;
  if (req.query.minPrice || req.query.maxPrice) spaceFilter.price = { ...(req.query.minPrice && { $gte: Number(req.query.minPrice) }), ...(req.query.maxPrice && { $lte: Number(req.query.maxPrice) }) };
  if (req.query.search) spaceFilter.$text = { $search: String(req.query.search) };

  const fetchSize = Math.min(page * limit, 500);
  const [properties, spaces, propertyTotal, spaceTotal] = await Promise.all([
    Property.find(propertyFilter).sort({ 'promotion.topListing': -1, 'promotion.featured': -1, publishedAt: -1, createdAt: -1 }).limit(fetchSize).populate('owner', 'name phone avatar kycStatus').lean(),
    PropertySpace.find(spaceFilter).sort({ 'promotion.topListing': -1, 'promotion.featured': -1, createdAt: -1 }).limit(fetchSize).populate({ path: 'property', populate: { path: 'owner', select: 'name phone avatar kycStatus' } }).lean(),
    Property.countDocuments(propertyFilter), PropertySpace.countDocuments(spaceFilter),
  ]);
  const combined = [...properties.map(formatProperty), ...spaces.filter((item) => item.property).map(formatSpace)]
    .sort((a, b) => Number(Boolean(b.promotion?.topListing || b.isFeatured)) - Number(Boolean(a.promotion?.topListing || a.isFeatured)) || new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime());
  const data = combined.slice((page - 1) * limit, page * limit);
  const total = propertyTotal + spaceTotal;
  res.json({ success: true, data, total, page, limit, totalPages: Math.ceil(total / limit) });
});
export const getPublicProperty = asyncHandler(async (req, res) => {
  const filter = await publicFilter({ _id: req.params.id });
  const doc = await Property.findOne(filter).populate('manager', 'name email phone').populate('owner', 'name phone avatar kycStatus').lean();
  if (doc) return res.json({ success: true, data: formatProperty(doc) });
  const activeOwnerIds = await activeLandlordIds();
  const space = await PropertySpace.findOne({ _id: req.params.id, owner: { $in: activeOwnerIds }, visibility: 'public', publicationStatus: 'published', status: 'available', deletedAt: null })
    .populate({ path: 'property', populate: { path: 'owner', select: 'name phone avatar kycStatus' } }).lean();
  if (!space?.property || space.property.visibility !== 'public' || space.property.publicationStatus !== 'published') throw new ApiError(404, 'Property listing not found or no longer public');
  res.json({ success: true, data: formatSpace(space) });
});

// Surveyor marketplace
import crypto from 'crypto';
import { SurveyorSubscription, SurveyorProfile, SurveyService, SurveyJob } from '../models/index.js';

async function activeSurveyorIds() {
  const now = new Date();
  return SurveyorSubscription.distinct('user', {
    $or: [
      { status: { $in: ['trial', 'active', 'expiring_soon'] }, expiresAt: { $gt: now } },
      { status: 'grace_period', graceEndsAt: { $gt: now } },
    ],
  });
}
function publicProfileProjection() {
  return '-privateShare -createdBy -updatedBy';
}
function sanitizeJob(job) {
  const value = { ...job };
  delete value.exactLocation; delete value.contact; delete value.documents; delete value.shortlistedSurveyors;
  if (value.location?.coordinates) value.location = { type: 'Point', coordinates: value.location.coordinates.map((item) => Math.round(Number(item) * 100) / 100) };
  return value;
}

export const listPublicSurveyors = asyncHandler(async (req, res) => {
  const page = Math.max(Number(req.query.page || 1), 1); const limit = Math.min(Math.max(Number(req.query.limit || 12), 1), 50);
  const ids = await activeSurveyorIds();
  const filter = { user: { $in: ids }, visibility: 'public', publicationStatus: 'published', verificationStatus: 'verified' };
  if (req.query.type && req.query.type !== 'all') filter.profileType = req.query.type;
  if (req.query.available === 'true') filter.availability = 'available';
  if (req.query.verified === 'true') filter.verificationStatus = 'verified';
  if (req.query.featured === 'true') filter.isFeatured = true;
  if (req.query.location) filter.$or = [
    { 'serviceLocations.city': new RegExp(String(req.query.location), 'i') },
    { 'serviceLocations.state': new RegExp(String(req.query.location), 'i') },
  ];
  if (req.query.category) filter.specialisations = String(req.query.category);
  if (req.query.minExperience) filter.yearsExperience = { $gte: Number(req.query.minExperience) };
  if (req.query.minRating) filter['rating.average'] = { $gte: Number(req.query.minRating) };
  if (req.query.search) filter.$text = { $search: String(req.query.search) };
  const sortMap = {
    highest_rated: { 'rating.average': -1, 'rating.count': -1 }, most_experienced: { yearsExperience: -1 },
    lowest_price: { startingPrice: 1 }, highest_price: { startingPrice: -1 }, most_completed: { completedProjects: -1 },
    fastest_response: { 'metrics.responseMinutes': 1 }, recently_joined: { createdAt: -1 }, recommended: { isFeatured: -1, isRecommended: -1, 'rating.average': -1 },
  };
  const sort = sortMap[String(req.query.sort || 'recommended')] || sortMap.recommended;
  const [data, total] = await Promise.all([
    SurveyorProfile.find(filter).select(publicProfileProjection()).sort(sort).skip((page - 1) * limit).limit(limit).lean(),
    SurveyorProfile.countDocuments(filter),
  ]);
  res.json({ success: true, data, total, page, limit, totalPages: Math.ceil(total / limit) });
});

export const getPublicSurveyor = asyncHandler(async (req, res) => {
  const ids = await activeSurveyorIds();
  const query = req.params.id.match(/^[a-f\d]{24}$/i) ? { _id: req.params.id } : { publicSlug: req.params.id };
  const profile = await SurveyorProfile.findOne({ ...query, user: { $in: ids }, visibility: 'public', publicationStatus: 'published', verificationStatus: 'verified' }).select(publicProfileProjection()).lean();
  if (!profile) throw new ApiError(404, 'Surveyor profile not found');
  const services = await SurveyService.find({ surveyor: profile.user, visibility: 'public', status: 'published', 'moderation.status': 'approved' }).select('-createdBy -updatedBy').sort({ isFeatured: -1, createdAt: -1 }).lean();
  await SurveyorProfile.updateOne({ _id: profile._id }, { $inc: { 'metrics.views': 1 } });
  res.json({ success: true, data: { ...profile, services } });
});

export const getPrivateSurveyor = asyncHandler(async (req, res) => {
  const token = String(req.query.token || '');
  if (!token) throw new ApiError(401, 'Private access token required');
  const tokenHash = crypto.createHash('sha256').update(token).digest('hex');
  const profileRecord = await SurveyorProfile.findOne({ _id: req.params.id, 'privateShare.enabled': true, 'privateShare.tokenHash': tokenHash, 'privateShare.revokedAt': { $exists: false } });
  if (!profileRecord) throw new ApiError(404, 'Private profile link is invalid or revoked');
  if (profileRecord.privateShare?.passwordHash) {
    const code = String(req.query.code || '');
    const codeHash = crypto.createHash('sha256').update(code).digest('hex');
    if (!code || codeHash !== profileRecord.privateShare.passwordHash) throw new ApiError(401, 'Private profile access code required');
  }
  const profile = await SurveyorProfile.findById(profileRecord._id).select(publicProfileProjection()).lean();
  const services = await SurveyService.find({ surveyor: profile.user, visibility: 'private', status: { $nin: ['archived'] } }).select('-createdBy -updatedBy').lean();
  res.json({ success: true, data: { ...profile, services } });
});

export const listPublicSurveyServices = asyncHandler(async (req, res) => {
  const page = Math.max(Number(req.query.page || 1), 1); const limit = Math.min(Math.max(Number(req.query.limit || 12), 1), 50);
  const ids = await activeSurveyorIds();
  const filter = { surveyor: { $in: ids }, visibility: 'public', status: 'published', 'moderation.status': 'approved' };
  if (req.query.category) filter.category = req.query.category;
  if (req.query.subtype) filter.subtype = req.query.subtype;
  if (req.query.minPrice || req.query.maxPrice) filter.startingPrice = { ...(req.query.minPrice && { $gte: Number(req.query.minPrice) }), ...(req.query.maxPrice && { $lte: Number(req.query.maxPrice) }) };
  if (req.query.location) filter.$or = [{ 'coverageAreas.city': new RegExp(String(req.query.location), 'i') }, { 'coverageAreas.state': new RegExp(String(req.query.location), 'i') }];
  if (req.query.emergency === 'true') filter.emergencyAvailable = true;
  if (req.query.online === 'true') filter.onlineConsultation = true;
  if (req.query.search) filter.$text = { $search: String(req.query.search) };
  const sort = req.query.sort === 'lowest_price' ? { startingPrice: 1 } : req.query.sort === 'highest_price' ? { startingPrice: -1 } : { isFeatured: -1, createdAt: -1 };
  const [data, total] = await Promise.all([
    SurveyService.find(filter).populate('profile', 'name profilePhoto agencyLogo verificationStatus rating publicSlug availability').sort(sort).skip((page - 1) * limit).limit(limit).lean(),
    SurveyService.countDocuments(filter),
  ]);
  res.json({ success: true, data, total, page, limit, totalPages: Math.ceil(total / limit) });
});

export const listPublicSurveyJobs = asyncHandler(async (req, res) => {
  const page = Math.max(Number(req.query.page || 1), 1); const limit = Math.min(Math.max(Number(req.query.limit || 20), 1), 50);
  const filter = { visibility: 'public', status: 'open', $or: [{ closesAt: null }, { closesAt: { $gt: new Date() } }, { closesAt: { $exists: false } }] };
  if (req.query.category) filter.surveyType = req.query.category;
  if (req.query.location) filter.addressApproximate = new RegExp(String(req.query.location), 'i');
  if (req.query.urgency) filter.urgency = req.query.urgency;
  if (req.query.minBudget || req.query.maxBudget) filter['budget.max'] = { ...(req.query.minBudget && { $gte: Number(req.query.minBudget) }), ...(req.query.maxBudget && { $lte: Number(req.query.maxBudget) }) };
  if (req.query.search) filter.$text = { $search: String(req.query.search) };
  const [jobs, total] = await Promise.all([SurveyJob.find(filter).sort({ urgency: -1, createdAt: -1 }).skip((page - 1) * limit).limit(limit).lean(), SurveyJob.countDocuments(filter)]);
  res.json({ success: true, data: jobs.map(sanitizeJob), total, page, limit, totalPages: Math.ceil(total / limit) });
});
