import { SiteSetting, SeoPage, HomeCarousel, HomeSection, LandlordPlan, PropertyTypeConfig, AreaUnit, SiteEnquiry, Property, PropertySpace, PropertyMedia, Subscription } from '../models/index.js';
import { asyncHandler } from '../utils/asyncHandler.js';
import { ApiError } from '../utils/apiError.js';
import { ensureLandlordPlans } from '../services/landlordSubscription.js';

async function ensureSiteSetting() {
  let setting = await SiteSetting.findOne({ key: 'default' }).lean();
  if (!setting) {
    setting = (await SiteSetting.create({
      key: 'default', siteTitle: 'SecureAsset', shortTitle: 'SecureAsset',
      tagline: 'Property, tenancy and survey management in one secure platform.',
      description: 'Manage properties, tenants, surveys, legal records and payments from one secure platform.',
      contact: { email: 'hello@secureasset.in', phone: '+91 00000 00000', address: 'India' },
      seo: { defaultTitle: 'SecureAsset — Property, Tenant and Survey Management', defaultDescription: 'Discover properties and manage the complete rental, tenancy and survey lifecycle.', titleTemplate: '%s | SecureAsset', robots: 'index,follow' },
    })).toObject();
  }
  return setting;
}

export const getPublicSite = asyncHandler(async (req, res) => {
  await ensureLandlordPlans();
  const now = new Date();
  const path = String(req.query.path || '/').split('?')[0] || '/';
  const [settings, seo, carousel, sections, landlordPlans, propertyTypes, areaUnits] = await Promise.all([
    ensureSiteSetting(),
    SeoPage.findOne({ path, active: true }).lean(),
    HomeCarousel.find({ active: true, $and: [{ $or: [{ startsAt: null }, { startsAt: { $lte: now } }, { startsAt: { $exists: false } }] }, { $or: [{ endsAt: null }, { endsAt: { $gt: now } }, { endsAt: { $exists: false } }] }] }).sort({ sortOrder: 1, createdAt: 1 }).lean(),
    HomeSection.find({ active: true }).sort({ sortOrder: 1 }).lean(),
    LandlordPlan.find({ active: true }).sort({ rank: 1 }).lean(),
    PropertyTypeConfig.find({ active: true }).sort({ sortOrder: 1, label: 1 }).lean(),
    AreaUnit.find({ active: true }).sort({ sortOrder: 1, label: 1 }).lean(),
  ]);
  const safeSettings = { ...settings };
  if (safeSettings.map) delete safeSettings.map.privateApiKey;
  res.set('Cache-Control', 'public, max-age=60, stale-while-revalidate=300');
  res.json({ success: true, data: { settings: safeSettings, seo, carousel, sections, landlordPlans, propertyTypes, areaUnits } });
});

export const submitSiteEnquiry = asyncHandler(async (req, res) => {
  const body = {
    name: String(req.body.name || '').trim(), email: String(req.body.email || '').trim().toLowerCase(), phone: String(req.body.phone || '').trim(),
    message: String(req.body.message || '').trim(), property: req.body.property || undefined, space: req.body.space || undefined,
    type: req.body.property ? 'property' : (req.body.type || 'contact'), status: 'new',
  };
  if (!body.name || (!body.email && !body.phone) || !body.message) throw new ApiError(422, 'Name, message and email or phone are required');
  const data = await SiteEnquiry.create(body);
  res.status(201).json({ success: true, data: { _id: data._id }, message: 'Your enquiry has been submitted' });
});

export const getPublicPropertyStructure = asyncHandler(async (req, res) => {
  const activeOwnerIds = await Subscription.distinct('user', { status: 'active', expiresAt: { $gt: new Date() } });
  let selectedSpace = null;
  let property = await Property.findOne({ _id: req.params.id, owner: { $in: activeOwnerIds }, visibility: 'public', publicationStatus: 'published', status: { $in: ['available', 'partially_occupied'] }, deletedAt: null }).populate('owner', 'name avatar kycStatus').lean();
  if (!property) {
    selectedSpace = await PropertySpace.findOne({ _id: req.params.id, owner: { $in: activeOwnerIds }, visibility: 'public', publicationStatus: 'published', status: 'available', deletedAt: null }).lean();
    if (selectedSpace) property = await Property.findOne({ _id: selectedSpace.property, owner: { $in: activeOwnerIds }, visibility: 'public', publicationStatus: 'published', status: { $in: ['available', 'partially_occupied'] }, deletedAt: null }).populate('owner', 'name avatar kycStatus').lean();
  }
  if (!property) throw new ApiError(404, 'Property not found');
  const [spaces, media] = await Promise.all([
    PropertySpace.find({ property: property._id, visibility: 'public', publicationStatus: 'published', status: { $in: ['available', 'reserved'] }, deletedAt: null }).sort({ sortOrder: 1, createdAt: 1 }).lean(),
    PropertyMedia.find({ property: property._id, visibility: 'public', deletedAt: null }).sort({ cover: -1, sortOrder: 1, createdAt: 1 }).lean(),
  ]);
  const nodes = new Map(spaces.map((space) => [String(space._id), { ...space, children: [], media: [] }]));
  const roots = [];
  nodes.forEach((node) => {
    const parentId = node.parent ? String(node.parent) : null;
    if (parentId && nodes.has(parentId)) nodes.get(parentId).children.push(node); else roots.push(node);
  });
  media.forEach((item) => { if (item.space && nodes.has(String(item.space))) nodes.get(String(item.space)).media.push(item); });
  const propertyMedia = media.filter((item) => !item.space);
  const publicProperty = { ...property };
  if (property.locationPrivacy !== 'exact_public') {
    if (publicProperty.address) { delete publicProperty.address.line1; delete publicProperty.address.line2; }
    if (publicProperty.map) { delete publicProperty.map.latitude; delete publicProperty.map.longitude; }
    if (publicProperty.location?.coordinates) publicProperty.location.coordinates = publicProperty.location.coordinates.map((value) => Math.round(Number(value) * 100) / 100);
  }
  await Property.updateOne({ _id: property._id }, { $inc: { 'metrics.views': 1 } });
  if (selectedSpace) await PropertySpace.updateOne({ _id: selectedSpace._id }, { $inc: { 'metrics.views': 1 } });
  res.json({ success: true, data: { property: publicProperty, selectedSpace, spaces: roots, media: propertyMedia } });
});
