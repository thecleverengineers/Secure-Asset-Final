import crypto from 'crypto';
import fs from 'fs/promises';
import path from 'path';
import { Document } from '../models/index.js';
import { asyncHandler } from '../utils/asyncHandler.js';
import { ApiError } from '../utils/apiError.js';
import { getActiveSurveyorSubscription, calculateSurveyorUsage } from '../services/surveyorSubscription.js';

async function removeQuietly(filePath) { try { await fs.unlink(filePath); } catch {} }
function basicSecurityScan(buffer, mimeType) {
  const head = buffer.subarray(0, 16); const text = buffer.toString('utf8', 0, Math.min(buffer.length, 8192));
  if (text.includes('EICAR-STANDARD-ANTIVIRUS-TEST-FILE')) return 'Malware test signature detected';
  if (head[0] === 0x4d && head[1] === 0x5a) return 'Executable content is not allowed';
  if (mimeType === 'application/pdf' && !buffer.subarray(0, 5).equals(Buffer.from('%PDF-'))) return 'Invalid PDF file signature';
  if (mimeType === 'image/png' && !buffer.subarray(0, 8).equals(Buffer.from([137,80,78,71,13,10,26,10]))) return 'Invalid PNG file signature';
  return null;
}

export const uploadDocument = asyncHandler(async (req, res) => {
  if (!req.file) throw new ApiError(422, 'Choose a file to upload');
  const buffer = await fs.readFile(req.file.path);
  const scanError = basicSecurityScan(buffer, req.file.mimetype);
  if (scanError) { await removeQuietly(req.file.path); throw new ApiError(422, scanError); }
  if (req.user.activeMode === 'surveyor' || String(req.body.context || '').startsWith('survey')) {
    try {
      const sub = await getActiveSurveyorSubscription(req.user._id);
      const usage = await calculateSurveyorUsage(req.user._id, sub);
      if (req.file.size > Number(usage.remaining.storageBytes || 0)) { await removeQuietly(req.file.path); throw new ApiError(403, 'Surveyor document storage limit reached'); }
    } catch (error) { if (error instanceof ApiError) { await removeQuietly(req.file.path); throw error; } }
  }
  const checksum = crypto.createHash('sha256').update(buffer).digest('hex');
  const owner = req.user.role === 'admin' && req.body.owner ? req.body.owner : req.user._id;
  const document = await Document.create({
    name: req.body.name || req.file.originalname, type: req.body.type || 'other', url: `/uploads/${path.basename(req.file.path)}`,
    mimeType: req.file.mimetype, sizeBytes: req.file.size, owner, property: req.body.property || undefined,
    visibility: req.body.visibility || 'private', checksum, uploadedBy: req.user._id,
  });
  res.status(201).json({ success: true, data: document });
});
