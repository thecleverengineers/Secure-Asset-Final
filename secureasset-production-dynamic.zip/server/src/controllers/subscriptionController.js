import { Subscription, User, Property, PropertySpace, Payment, AuditLog, LandlordPlan } from '../models/index.js';
import { asyncHandler } from '../utils/asyncHandler.js';
import { ApiError } from '../utils/apiError.js';
import { ensureLandlordPlans, syncLandlordLifecycle, usageWithLimits } from '../services/landlordSubscription.js';

export const listPlans = asyncHandler(async (_req, res) => {
  await ensureLandlordPlans();
  const data = await LandlordPlan.find({ active: true }).sort({ rank: 1 }).lean();
  res.json({ success: true, data });
});

export const mySubscription = asyncHandler(async (req, res) => {
  await syncLandlordLifecycle(req.user._id);
  const data = await usageWithLimits(req.user._id);
  res.json({ success: true, data });
});

export const checkout = asyncHandler(async (req, res) => {
  if (req.user.role !== 'tenant') throw new ApiError(403, 'Only Tenant accounts can purchase a Landlord subscription');
  await ensureLandlordPlans();
  const planKey = String(req.body.plan || 'starter').toLowerCase();
  const billingCycle = req.body.billingCycle === 'yearly' ? 'yearly' : 'monthly';
  const plan = await LandlordPlan.findOne({ key: planKey, active: true }).lean();
  if (!plan) throw new ApiError(422, 'Invalid or inactive subscription plan');
  if (plan.key === 'enterprise' && !req.body.adminApproved) throw new ApiError(422, 'Enterprise subscriptions require administrator approval');
  const amount = Number(plan.prices?.[billingCycle] || 0);
  const now = new Date();
  const expiresAt = new Date(now);
  billingCycle === 'yearly' ? expiresAt.setFullYear(expiresAt.getFullYear() + 1) : expiresAt.setMonth(expiresAt.getMonth() + 1);
  const transactionId = String(req.body.transactionId || `DEMO-SUB-${Date.now()}`);
  const subscription = await Subscription.create({
    user: req.user._id, plan: plan.key, billingCycle, amount, status: 'active', startsAt: now, expiresAt,
    limits: { ...plan.limits, ...plan.features },
    payment: { method: req.body.method || 'demo', transactionId, gateway: req.body.gateway || 'local', paidAt: now, metadata: { planSnapshot: plan } },
    createdBy: req.user._id, updatedBy: req.user._id,
  });
  await Subscription.updateMany({ user: req.user._id, _id: { $ne: subscription._id }, status: 'active' }, { status: 'cancelled', cancelledAt: now });
  await User.findByIdAndUpdate(req.user._id, { landlordEnabled: true, landlordSubscriptionExpiresAt: expiresAt });
  await Payment.create({ invoiceNumber: `SUB-${Date.now()}`, payer: req.user._id, type: 'landlord_subscription', amount, paidAmount: amount, status: 'paid', paidAt: now, method: 'gateway', transactionId, notes: `${plan.name} Landlord plan`, createdBy: req.user._id, updatedBy: req.user._id });
  await AuditLog.create({ user: req.user._id, role: req.user.role, action: 'subscription:activated', module: 'subscriptions', recordId: subscription._id, updatedValue: subscription.toObject() });
  res.status(201).json({ success: true, data: await usageWithLimits(req.user._id), message: 'Landlord subscription activated' });
});

export const cancel = asyncHandler(async (req, res) => {
  const subscription = await Subscription.findOne({ _id: req.params.id, user: req.user._id, status: 'active' });
  if (!subscription) throw new ApiError(404, 'Active subscription not found');
  subscription.status = 'cancelled'; subscription.cancelledAt = new Date(); await subscription.save();
  await User.findByIdAndUpdate(req.user._id, { landlordEnabled: false, activeMode: 'regular' });
  await Property.updateMany({ owner: req.user._id, requiresActiveSubscription: true }, { visibility: 'private', publicationStatus: 'draft' });
  await PropertySpace.updateMany({ owner: req.user._id }, { visibility: 'private', publicationStatus: 'draft' });
  res.json({ success: true, data: subscription, message: 'Subscription cancelled. Existing data remains saved and public listings were paused.' });
});
