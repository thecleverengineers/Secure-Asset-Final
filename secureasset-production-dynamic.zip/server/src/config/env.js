import dotenv from 'dotenv';
dotenv.config();

export const env = {
  NODE_ENV: process.env.NODE_ENV || 'development',
  PORT: Number(process.env.PORT || 5000),
  MONGODB_URI: process.env.MONGODB_URI || 'mongodb://127.0.0.1:27017/secureasset',
  JWT_ACCESS_SECRET: process.env.JWT_ACCESS_SECRET || 'change-this-access-secret',
  JWT_REFRESH_SECRET: process.env.JWT_REFRESH_SECRET || 'change-this-refresh-secret',
  ACCESS_TOKEN_TTL: process.env.ACCESS_TOKEN_TTL || '15m',
  REFRESH_TOKEN_TTL_DAYS: Number(process.env.REFRESH_TOKEN_TTL_DAYS || 30),
  CLIENT_URL: process.env.CLIENT_URL || 'http://localhost:5173',
  PUBLIC_APP_URL: process.env.PUBLIC_APP_URL || process.env.CLIENT_URL?.split(',')[0] || 'http://localhost:5173',
  UPLOAD_DIR: process.env.UPLOAD_DIR || 'server/src/uploads',
  MAX_FILE_MB: Number(process.env.MAX_FILE_MB || 10),
  LEGACY_PUBLIC_UPLOADS: process.env.LEGACY_PUBLIC_UPLOADS === 'true',
  CMS_ASSET_DIR: process.env.CMS_ASSET_DIR || 'storage/site-assets',
  DEMO_OTP: process.env.DEMO_OTP || '123456',
  SMTP_HOST: process.env.SMTP_HOST || '',
  SMTP_PORT: Number(process.env.SMTP_PORT || 587),
  SMTP_USER: process.env.SMTP_USER || '',
  SMTP_PASS: process.env.SMTP_PASS || '',
  SMTP_FROM: process.env.SMTP_FROM || 'SecureAsset <no-reply@secureasset.local>',
  STORAGE_DRIVER: process.env.STORAGE_DRIVER || 'local',
  VAULT_STORAGE_DIR: process.env.VAULT_STORAGE_DIR || 'storage/vault',
  VAULT_ENCRYPTION_KEY: process.env.VAULT_ENCRYPTION_KEY || '',
  VAULT_TEMP_DIR: process.env.VAULT_TEMP_DIR || 'storage/tmp',
  VAULT_MAX_FILE_MB: Number(process.env.VAULT_MAX_FILE_MB || 250),
  VAULT_CHUNK_MB: Number(process.env.VAULT_CHUNK_MB || 12),
  VAULT_ALLOWED_EXTENSIONS: process.env.VAULT_ALLOWED_EXTENSIONS || '.pdf,.doc,.docx,.txt,.rtf,.odt,.xls,.xlsx,.csv,.ppt,.pptx,.jpg,.jpeg,.png,.webp,.gif,.svg,.tiff,.heic,.mp4,.mov,.avi,.mkv,.webm,.mp3,.wav,.m4a,.aac,.dxf,.dwg,.kml,.kmz,.geojson,.zip,.rar,.7z',
  TRASH_RETENTION_DAYS: Number(process.env.TRASH_RETENTION_DAYS || 60),
  CLAMAV_ENABLED: process.env.CLAMAV_ENABLED === 'true',
  CLAMAV_COMMAND: process.env.CLAMAV_COMMAND || 'clamdscan',
  S3_REGION: process.env.S3_REGION || 'ap-south-1',
  S3_BUCKET: process.env.S3_BUCKET || '',
  S3_ENDPOINT: process.env.S3_ENDPOINT || '',
  S3_ACCESS_KEY_ID: process.env.S3_ACCESS_KEY_ID || '',
  S3_SECRET_ACCESS_KEY: process.env.S3_SECRET_ACCESS_KEY || '',
  S3_SSE: process.env.S3_SSE || 'AES256',
};

if (env.NODE_ENV === 'production') {
  const weak = ['change-this-access-secret', 'change-this-refresh-secret'];
  if (weak.includes(env.JWT_ACCESS_SECRET) || weak.includes(env.JWT_REFRESH_SECRET)) throw new Error('Production JWT secrets must be configured');
  if (env.STORAGE_DRIVER === 's3' && !env.S3_BUCKET) throw new Error('S3_BUCKET is required when STORAGE_DRIVER=s3');
  if (env.STORAGE_DRIVER === 'local' && env.VAULT_ENCRYPTION_KEY.length < 32) throw new Error('VAULT_ENCRYPTION_KEY must contain at least 32 characters for production local storage');
}
