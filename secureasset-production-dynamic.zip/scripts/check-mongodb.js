import mongoose from 'mongoose';
import dotenv from 'dotenv';

dotenv.config();
const uri = process.env.MONGODB_URI || 'mongodb://127.0.0.1:27017/secureasset';

try {
  await mongoose.connect(uri, { serverSelectionTimeoutMS: 5000 });
  console.log(`MongoDB connection successful: ${mongoose.connection.host}/${mongoose.connection.name}`);
  await mongoose.disconnect();
} catch (error) {
  console.error('MongoDB connection failed.');
  console.error(error?.message || error);
  console.error('\nStart MongoDB Community Server or update MONGODB_URI in .env with your Atlas connection string.');
  process.exit(1);
}
