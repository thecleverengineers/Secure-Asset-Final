import { connectDatabase, disconnectDatabase } from '../server/src/config/db.js';
import { User, Property, Subscription } from '../server/src/models/index.js';

await connectDatabase();
try {
  const userResult = await User.updateMany({ role: 'user' }, { $set: { role: 'tenant' } });
  const properties = await Property.find({});
  let updatedProperties = 0;
  for (const property of properties) {
    let changed = false;
    if (!property.listingType) { property.listingType = property.isSale ? 'sale' : 'rent'; changed = true; }
    if (!property.visibility) { property.visibility = 'private'; changed = true; }
    if (!property.publicationStatus) { property.publicationStatus = 'draft'; changed = true; }
    if (property.visibility === 'public' && property.publicationStatus !== 'published') { property.publicationStatus = 'published'; property.publishedAt ||= new Date(); changed = true; }
    if (changed) { await property.save({ validateModifiedOnly: true }); updatedProperties += 1; }
  }
  const active = await Subscription.find({ status: 'active', expiresAt: { $gt: new Date() } });
  for (const subscription of active) await User.findByIdAndUpdate(subscription.user, { landlordEnabled: true, landlordSubscriptionExpiresAt: subscription.expiresAt });
  console.log(`Migrated ${userResult.modifiedCount} user account(s) to tenant and normalised ${updatedProperties} property listing(s).`);
} finally { await disconnectDatabase(); }
