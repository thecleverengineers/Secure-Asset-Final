import fs from 'fs';
import path from 'path';
const required = ['dist/index.html', 'server/src/server.js', 'ecosystem.config.cjs'];
const missing = required.filter((entry) => !fs.existsSync(path.resolve(entry)));
if (missing.length) { console.error(`Production build verification failed. Missing: ${missing.join(', ')}`); process.exit(1); }
const html = fs.readFileSync(path.resolve('dist/index.html'), 'utf8');
if (!html.includes('/assets/')) { console.error('Production build verification failed: Vite asset references were not found.'); process.exit(1); }
console.log('Production build verified: dist/index.html and server runtime are ready.');
