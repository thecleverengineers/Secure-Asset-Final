import mongoose from 'mongoose';
import { connectDatabase, disconnectDatabase } from '../server/src/config/db.js';
import '../server/src/models/index.js';

try {
  await connectDatabase();
  for (const [name, Model] of Object.entries(mongoose.models)) {
    await Model.createIndexes();
    console.log(`Indexes ensured: ${name}`);
  }
  console.log('Production indexes created successfully.');
} catch (error) {
  console.error('Index creation failed:', error);
  process.exitCode = 1;
} finally {
  await disconnectDatabase().catch(() => {});
}
