#!/usr/bin/env sh
set -eu
cd "$(dirname "$0")"
node scripts/setup-local.js
npm install
npm run db:check
npm run seed
printf '\nSetup completed. Run ./start-unix.sh to launch the app.\n'
