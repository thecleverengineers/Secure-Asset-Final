import { useEffect, useState } from 'react';
import { useParams } from 'react-router';
import { Alert, Avatar, Box, Button, Card, CardContent, Chip, Grid, Paper, Stack, TextField, Typography } from '@mui/material';
import { DownloadRounded, SaveRounded } from '@mui/icons-material';
import { useAuth } from '../../context/AuthContext';
import { downloadReport, getResource } from '../../services/api';
import { moduleLabel } from '../../components/layout/AppShell';

const reportModules = ['properties', 'units', 'tenants', 'leases', 'surveys', 'applications', 'payments', 'complaints', 'approvals', 'audit-logs'];

export default function UtilityPage() {
  const { module = '' } = useParams();
  const { user } = useAuth();
  const [related, setRelated] = useState<any[]>([]);
  const [notice, setNotice] = useState('');

  useEffect(() => {
    if (module === 'my-property') getResource('tenants', { limit: 10 }).then((r) => setRelated(r.data)).catch(() => {});
  }, [module]);

  if (module === 'profile') return <Box sx={{ px: { xs: 2, sm: 3, lg: 4 }, pb: 5 }}><Typography variant="h4" sx={{ fontWeight: 900, mb: 3 }}>My Profile</Typography><Paper elevation={0} sx={{ p: 3, borderRadius: 4, border: '1px solid', borderColor: 'divider', maxWidth: 760 }}><Stack direction={{ xs: 'column', sm: 'row' }} spacing={3}><Avatar src={user?.avatar} sx={{ width: 90, height: 90, bgcolor: 'primary.main', fontSize: 32 }}>{user?.name?.[0]}</Avatar><Box sx={{ flex: 1, display: 'grid', gridTemplateColumns: { xs: '1fr', sm: '1fr 1fr' }, gap: 2 }}><TextField label="Name" value={user?.name || ''} InputProps={{ readOnly: true }} /><TextField label="Role" value={user?.role || ''} InputProps={{ readOnly: true }} /><TextField label="Email" value={user?.email || ''} InputProps={{ readOnly: true }} /><TextField label="Phone" value={user?.phone || ''} InputProps={{ readOnly: true }} /><TextField label="Region" value={user?.region || ''} InputProps={{ readOnly: true }} /><TextField label="KYC status" value={user?.kycStatus || ''} InputProps={{ readOnly: true }} /></Box></Stack></Paper></Box>;

  if (module === 'reports') return <Box sx={{ px: { xs: 2, sm: 3, lg: 4 }, pb: 5 }}><Typography variant="h4" sx={{ fontWeight: 900 }}>Reports & Analytics</Typography><Typography color="text.secondary" sx={{ mt: .5, mb: 3 }}>Download live, permission-scoped MongoDB records as CSV.</Typography><Grid container spacing={2}>{reportModules.map((resource) => <Grid size={{ xs: 12, sm: 6, md: 4 }} key={resource}><Card elevation={0} sx={{ borderRadius: 4, border: '1px solid', borderColor: 'divider' }}><CardContent><Typography sx={{ fontWeight: 850 }}>{moduleLabel(resource)}</Typography><Typography color="text.secondary" sx={{ fontSize: 12, my: 1.5 }}>Includes current filters and only records available to your role.</Typography><Button startIcon={<DownloadRounded />} variant="outlined" onClick={() => downloadReport(resource).catch((e) => setNotice(e.message))}>Export CSV</Button></CardContent></Card></Grid>)}</Grid>{notice && <Alert severity="error" sx={{ mt: 2 }}>{notice}</Alert>}</Box>;

  if (module === 'my-property') return <Box sx={{ px: { xs: 2, sm: 3, lg: 4 }, pb: 5 }}><Typography variant="h4" sx={{ fontWeight: 900, mb: 3 }}>My Property</Typography>{related.length ? related.map((tenant) => <Card key={tenant._id} elevation={0} sx={{ borderRadius: 4, border: '1px solid', borderColor: 'divider', maxWidth: 900 }}><CardContent><Stack direction={{ xs: 'column', md: 'row' }} justifyContent="space-between" spacing={2}><Box><Chip label={tenant.status} color="success" size="small" /><Typography sx={{ mt: 1.5, fontSize: 24, fontWeight: 900 }}>{tenant.property?.title || 'Assigned property'}</Typography><Typography color="text.secondary">{tenant.property?.address?.line1}, {tenant.property?.address?.city}</Typography><Typography sx={{ mt: 1, fontWeight: 700 }}>Unit {tenant.unit?.unitNumber || '—'}</Typography></Box><Box><Typography color="text.secondary" sx={{ fontSize: 12 }}>MOVE-IN DATE</Typography><Typography sx={{ fontWeight: 800 }}>{tenant.moveInDate ? new Date(tenant.moveInDate).toLocaleDateString('en-IN', { dateStyle: 'long' }) : '—'}</Typography></Box></Stack></CardContent></Card>) : <Alert severity="info">No active property allocation was found.</Alert>}</Box>;

  if (module === 'settings') return <Box sx={{ px: { xs: 2, sm: 3, lg: 4 }, pb: 5 }}><Typography variant="h4" sx={{ fontWeight: 900, mb: 3 }}>System Settings</Typography><Paper elevation={0} sx={{ p: 3, borderRadius: 4, border: '1px solid', borderColor: 'divider', maxWidth: 820 }}><Stack spacing={2}><TextField label="Organisation name" defaultValue="SecureAsset Property Management" /><TextField label="Default currency" defaultValue="INR" /><TextField label="Default timezone" defaultValue="Asia/Kolkata" /><TextField label="Support email" defaultValue="support@secureasset.in" /><Button variant="contained" startIcon={<SaveRounded />} onClick={() => setNotice('Settings saved locally. Add organisation settings model for production persistence.')}>Save settings</Button>{notice && <Alert severity="success">{notice}</Alert>}</Stack></Paper></Box>;

  if (module === 'facilities') return <Box sx={{ px: { xs: 2, sm: 3, lg: 4 }, pb: 5 }}><Typography variant="h4" sx={{ fontWeight: 900, mb: 3 }}>Facilities</Typography><Grid container spacing={2}>{['Community Hall', 'Visitor Parking', 'Fitness Room', 'Meeting Lounge'].map((name, index) => <Grid size={{ xs: 12, sm: 6, md: 3 }} key={name}><Card elevation={0} sx={{ borderRadius: 4, border: '1px solid', borderColor: 'divider' }}><CardContent><Typography sx={{ fontWeight: 850 }}>{name}</Typography><Typography color="text.secondary" sx={{ fontSize: 12, my: 1 }}>{index % 2 ? 'Available today' : 'Next slot: Tomorrow'}</Typography><Button size="small" variant="outlined">Request booking</Button></CardContent></Card></Grid>)}</Grid></Box>;

  return <Box sx={{ px: 4, py: 6 }}><Alert severity="info">{moduleLabel(module)} is ready for organisation-specific configuration.</Alert></Box>;
}
