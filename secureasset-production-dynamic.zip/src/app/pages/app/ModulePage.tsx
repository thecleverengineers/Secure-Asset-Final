import { useParams } from 'react-router';
import { useAuth } from '../../context/AuthContext';
import ResourcePage, { supportedResources } from './ResourcePage';
import UtilityPage from './UtilityPage';
import SurveyorSurveysPage from './SurveyorSurveysPage';
import SubscriptionPage from './SubscriptionPage';
import SurveyorSubscriptionPage from './SurveyorSubscriptionPage';
import SurveyorDashboardPage from './SurveyorDashboardPage';
import SurveyorVerificationPage from './SurveyorVerificationPage';
import SurveyorProfilePage from './SurveyorProfilePage';
import SurveyJobMarketplacePage from './SurveyJobMarketplacePage';
import SurveyorFieldPage from './SurveyorFieldPage';
import SurveyorInvoicesPage from './SurveyorInvoicesPage';
import DocumentVaultPage from './DocumentVaultPage';
import DriveAdministrationPage from './DriveAdministrationPage';
import SiteAdministrationPage from './SiteAdministrationPage';
import PropertyManagementPage from './PropertyManagementPage';
import TenantKycPage from './TenantKycPage';

export default function ModulePage() {
  const { module = '' } = useParams();
  const { user } = useAuth();
  if (module === 'surveys' && (user?.role === 'surveyor' || user?.activeMode === 'surveyor')) return <SurveyorSurveysPage />;
  if (module === 'subscription') return <SubscriptionPage />;
  if (module === 'surveyor-subscription') return <SurveyorSubscriptionPage />;
  if (module === 'surveyor-dashboard') return <SurveyorDashboardPage />;
  if (module === 'surveyor-verification') return <SurveyorVerificationPage />;
  if (module === 'surveyor-profile') return <SurveyorProfilePage />;
  if (module === 'survey-job-marketplace') return <SurveyJobMarketplacePage />;
  if (module === 'field-data') return <SurveyorFieldPage />;
  if (module === 'payments' && user?.activeMode === 'surveyor') return <SurveyorInvoicesPage />;
  if (module === 'documents') return <DocumentVaultPage />;
  if (module === 'drive-admin' && user?.role === 'admin') return <DriveAdministrationPage />;
  if (module === 'site-admin' && user?.role === 'admin') return <SiteAdministrationPage />;
  if (module === 'property-management' && (user?.role === 'admin' || user?.role === 'manager' || user?.activeMode === 'landlord')) return <PropertyManagementPage />;
  if (module === 'tenant-kyc' && user?.role === 'tenant') return <TenantKycPage />;
  if (supportedResources.includes(module)) return <ResourcePage />;
  return <UtilityPage />;
}
