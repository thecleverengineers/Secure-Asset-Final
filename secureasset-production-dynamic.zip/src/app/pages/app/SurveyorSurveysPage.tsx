import { useEffect, useState } from 'react';
import {
  Alert, Box, Button, Card, CardContent, Chip, Dialog, DialogActions, DialogContent, DialogTitle, Grid, LinearProgress,
  Stack, Step, StepLabel, Stepper, TextField, Typography,
} from '@mui/material';
import { CameraAltRounded, GpsFixedRounded, PlayArrowRounded, SaveRounded, SendRounded } from '@mui/icons-material';
import { changeResourceStatus, getResource, updateResource, uploadDocument } from '../../services/api';

const steps = ['Property condition', 'Occupancy & utilities', 'GPS & photographs', 'Review & submit'];

export default function SurveyorSurveysPage() {
  const [surveys, setSurveys] = useState<any[]>([]);
  const [selected, setSelected] = useState<any>(null);
  const [step, setStep] = useState(0);
  const [form, setForm] = useState<any>({ conditionRating: 3, occupancy: 'occupied', electricityMeter: '', waterSupply: 'available', notes: '', photos: [], gps: null });
  const [notice, setNotice] = useState('');
  const [error, setError] = useState('');
  const [online, setOnline] = useState(navigator.onLine);

  async function load() { try { setSurveys((await getResource('surveys', { limit: 100, sort: 'deadline' })).data); } catch (e) { setError((e as Error).message); } }
  useEffect(() => { load(); const on = () => setOnline(navigator.onLine); addEventListener('online', on); addEventListener('offline', on); return () => { removeEventListener('online', on); removeEventListener('offline', on); }; }, []);

  function open(survey: any) {
    const draft = localStorage.getItem(`survey-draft-${survey._id}`);
    setSelected(survey); setStep(0); setForm(draft ? JSON.parse(draft) : { conditionRating: 3, occupancy: 'occupied', electricityMeter: '', waterSupply: 'available', notes: '', photos: survey.photos || [], gps: survey.gps || null });
  }
  function saveDraft() { if (!selected) return; localStorage.setItem(`survey-draft-${selected._id}`, JSON.stringify(form)); setNotice('Draft saved on this device'); }
  function captureGps() { navigator.geolocation.getCurrentPosition((p) => setForm((f: any) => ({ ...f, gps: { lat: p.coords.latitude, lng: p.coords.longitude, accuracy: p.coords.accuracy, capturedAt: new Date().toISOString(), verified: p.coords.accuracy <= 50 } })), (e) => setError(e.message), { enableHighAccuracy: true, timeout: 10000 }); }
  async function addPhoto(file?: File) {
    if (!file) return;
    try { const result = await uploadDocument(file, { type: 'photo', visibility: 'property', property: selected.property?._id || selected.property }); setForm((f: any) => ({ ...f, photos: [...f.photos, { url: result.data.url, caption: file.name, capturedAt: new Date().toISOString(), ...(f.gps || {}) }] })); }
    catch (e) { setError((e as Error).message); }
  }
  async function startSurvey(survey: any) { try { await changeResourceStatus('surveys', survey._id, 'in_progress'); open({ ...survey, status: 'in_progress' }); await load(); } catch (e) { setError((e as Error).message); } }
  async function submit() {
    if (!selected) return;
    try {
      if (!form.gps) throw new Error('Capture GPS before submitting');
      if (!form.photos.length) throw new Error('Add at least one photograph');
      await updateResource('surveys', selected._id, { responses: { conditionRating: Number(form.conditionRating), occupancy: form.occupancy, electricityMeter: form.electricityMeter, waterSupply: form.waterSupply }, gps: form.gps, photos: form.photos, notes: form.notes, syncStatus: online ? 'synced' : 'pending' });
      if (online) await changeResourceStatus('surveys', selected._id, 'submitted', 'Field survey completed');
      localStorage.removeItem(`survey-draft-${selected._id}`); setSelected(null); setNotice(online ? 'Survey submitted successfully' : 'Survey saved offline and queued for sync'); await load();
    } catch (e) { setError((e as Error).message); }
  }

  return <Box sx={{ px: { xs: 2, sm: 3, lg: 4 }, pb: 5 }}>
    <Stack direction={{ xs: 'column', sm: 'row' }} justifyContent="space-between" spacing={2} sx={{ mb: 3 }}><Box><Typography variant="h4" sx={{ fontWeight: 900 }}>Field Surveys</Typography><Typography color="text.secondary" sx={{ fontSize: 13 }}>{surveys.length} assignments · {online ? 'Online and synced' : 'Offline mode'}</Typography></Box><Chip label={online ? 'Online' : 'Offline'} color={online ? 'success' : 'warning'} /></Stack>
    {error && <Alert severity="error" onClose={() => setError('')} sx={{ mb: 2 }}>{error}</Alert>}{notice && <Alert severity="success" onClose={() => setNotice('')} sx={{ mb: 2 }}>{notice}</Alert>}
    <Grid container spacing={2}>{surveys.map((survey) => <Grid size={{ xs: 12, md: 6, lg: 4 }} key={survey._id}><Card elevation={0} sx={{ border: '1px solid', borderColor: 'divider', borderRadius: 4, height: '100%' }}><CardContent><Stack direction="row" justifyContent="space-between"><Chip size="small" label={survey.priority} color={survey.priority === 'urgent' ? 'error' : survey.priority === 'high' ? 'warning' : 'default'} /><Chip size="small" label={survey.status.replaceAll('_', ' ')} variant="outlined" /></Stack><Typography sx={{ mt: 2, fontSize: 18, fontWeight: 850 }}>{survey.title}</Typography><Typography color="text.secondary" sx={{ fontSize: 12, mt: .5 }}>{survey.property?.title}</Typography><Typography sx={{ mt: 1.5, fontSize: 12 }}>Deadline: {survey.deadline ? new Date(survey.deadline).toLocaleString('en-IN') : 'Not set'}</Typography><Stack direction="row" spacing={1} sx={{ mt: 2 }}>{['assigned', 'returned'].includes(survey.status) ? <Button fullWidth variant="contained" startIcon={<PlayArrowRounded />} onClick={() => startSurvey(survey)}>Start survey</Button> : survey.status === 'in_progress' ? <Button fullWidth variant="contained" onClick={() => open(survey)}>Continue</Button> : <Button fullWidth variant="outlined" onClick={() => open(survey)}>View</Button>}</Stack></CardContent></Card></Grid>)}</Grid>

    <Dialog open={Boolean(selected)} onClose={() => setSelected(null)} fullScreen={matchMedia('(max-width: 700px)').matches} fullWidth maxWidth="md">
      <DialogTitle sx={{ fontWeight: 900 }}>{selected?.title}</DialogTitle><DialogContent dividers><Stepper activeStep={step} alternativeLabel sx={{ mb: 4 }}>{steps.map((label) => <Step key={label}><StepLabel>{label}</StepLabel></Step>)}</Stepper><LinearProgress variant="determinate" value={((step + 1) / steps.length) * 100} sx={{ mb: 3, height: 7, borderRadius: 4 }} />
        {step === 0 && <Stack spacing={2}><TextField select SelectProps={{ native: true }} label="Condition rating" value={form.conditionRating} onChange={(e) => setForm({ ...form, conditionRating: e.target.value })}><option value="1">1 — Poor</option><option value="2">2 — Fair</option><option value="3">3 — Good</option><option value="4">4 — Very good</option><option value="5">5 — Excellent</option></TextField><TextField label="Condition notes" multiline rows={5} value={form.notes} onChange={(e) => setForm({ ...form, notes: e.target.value })} /></Stack>}
        {step === 1 && <Stack spacing={2}><TextField select SelectProps={{ native: true }} label="Occupancy" value={form.occupancy} onChange={(e) => setForm({ ...form, occupancy: e.target.value })}><option value="occupied">Occupied</option><option value="vacant">Vacant</option><option value="partially_occupied">Partially occupied</option></TextField><TextField label="Electricity meter number" value={form.electricityMeter} onChange={(e) => setForm({ ...form, electricityMeter: e.target.value })} /><TextField select SelectProps={{ native: true }} label="Water supply" value={form.waterSupply} onChange={(e) => setForm({ ...form, waterSupply: e.target.value })}><option value="available">Available</option><option value="intermittent">Intermittent</option><option value="unavailable">Unavailable</option></TextField></Stack>}
        {step === 2 && <Stack spacing={2}><Button variant="outlined" startIcon={<GpsFixedRounded />} onClick={captureGps}>{form.gps ? `GPS captured · ±${Math.round(form.gps.accuracy)}m` : 'Capture live GPS'}</Button><Button component="label" variant="outlined" startIcon={<CameraAltRounded />}>Capture / upload photograph<input hidden accept="image/*" capture="environment" type="file" onChange={(e) => addPhoto(e.target.files?.[0])} /></Button><Typography color="text.secondary" sx={{ fontSize: 12 }}>{form.photos.length} photograph(s) attached</Typography></Stack>}
        {step === 3 && <Stack spacing={1.2}><Typography sx={{ fontWeight: 850 }}>Submission checklist</Typography><Typography>Condition rating: {form.conditionRating}/5</Typography><Typography>Occupancy: {form.occupancy}</Typography><Typography>GPS: {form.gps ? `Captured (±${Math.round(form.gps.accuracy)}m)` : 'Missing'}</Typography><Typography>Photographs: {form.photos.length}</Typography><Alert severity={online ? 'success' : 'warning'}>{online ? 'Submission will sync immediately.' : 'The draft will remain on this device until connectivity returns.'}</Alert></Stack>}
      </DialogContent><DialogActions sx={{ p: 2 }}><Button startIcon={<SaveRounded />} onClick={saveDraft}>Save draft</Button><Box sx={{ flex: 1 }} />{step > 0 && <Button onClick={() => setStep((s) => s - 1)}>Back</Button>}{step < steps.length - 1 ? <Button variant="contained" onClick={() => setStep((s) => s + 1)}>Next</Button> : <Button variant="contained" startIcon={<SendRounded />} onClick={submit}>Submit survey</Button>}</DialogActions>
    </Dialog>
  </Box>;
}
