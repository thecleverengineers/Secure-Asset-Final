import { useEffect, useMemo, useState, type ChangeEvent } from 'react';
import {
  Alert, Box, Button, Card, CardContent, Chip, CircularProgress, Dialog, DialogActions, DialogContent, DialogTitle,
  Divider, FormControlLabel, Grid, IconButton, MenuItem, Paper, Stack, Switch, Tab, Tabs, TextField, Typography,
} from '@mui/material';
import { AddRounded, DeleteRounded, EditRounded, ImageRounded, RefreshRounded, SaveRounded, UploadRounded } from '@mui/icons-material';
import { createResource, deleteResource, getResource, updateResource, uploadSiteAsset } from '../../services/api';
import { useSite } from '../../context/SiteContext';

type FormShape = Record<string, any>;
const get = (object: any, path: string) => path.split('.').reduce((value, key) => value?.[key], object);
const set = (object: any, path: string, value: any) => { const keys = path.split('.'); let current = object; keys.slice(0, -1).forEach((key) => { current[key] ||= {}; current = current[key]; }); current[keys[keys.length - 1]] = value; return object; };
const sentence = (value: string) => value.replaceAll('_', ' ').replace(/\b\w/g, (letter) => letter.toUpperCase());

const siteFields = [
  ['siteTitle', 'Site title'], ['shortTitle', 'Short title'], ['tagline', 'Tagline'], ['description', 'Site description'],
  ['logoUrl', 'Primary logo URL'], ['logoLightUrl', 'Light-mode logo URL'], ['faviconUrl', 'Favicon URL'], ['defaultOgImageUrl', 'Default social image URL'],
  ['brand.primaryColor', 'Primary colour'], ['brand.secondaryColor', 'Secondary colour'], ['brand.accentColor', 'Accent colour'], ['brand.fontFamily', 'Font family'],
  ['contact.email', 'Contact email'], ['contact.phone', 'Contact phone'], ['contact.whatsapp', 'WhatsApp'], ['contact.address', 'Office address'], ['contact.supportHours', 'Support hours'],
  ['social.facebook', 'Facebook URL'], ['social.instagram', 'Instagram URL'], ['social.x', 'X URL'], ['social.linkedin', 'LinkedIn URL'], ['social.youtube', 'YouTube URL'],
  ['seo.defaultTitle', 'Default SEO title'], ['seo.defaultDescription', 'Default SEO description'], ['seo.titleTemplate', 'Title template'], ['seo.robots', 'Default robots'], ['seo.canonicalBaseUrl', 'Canonical base URL'], ['seo.googleSiteVerification', 'Google site verification token'],
  ['map.provider', 'Map provider'], ['map.publicApiKey', 'Public map API key'], ['map.defaultLatitude', 'Default map latitude'], ['map.defaultLongitude', 'Default map longitude'], ['map.defaultZoom', 'Default map zoom'], ['maintenance.message', 'Maintenance message'],
] as const;

type CollectionDefinition = { resource: string; title: string; description: string; columns: string[]; fields: Array<{ key: string; label: string; type?: 'text'|'number'|'boolean'|'select'|'textarea'|'array'|'json'; options?: string[]; required?: boolean }> };
const definitions: CollectionDefinition[] = [
  { resource: 'seo-pages', title: 'SEO Pages', description: 'Database-controlled title, description, social cards, robots and structured data for each route.', columns: ['path','title','robots','active'], fields: [
    { key:'path',label:'Route path',required:true },{key:'title',label:'SEO title',required:true},{key:'description',label:'Meta description',type:'textarea'},{key:'keywords',label:'Keywords',type:'array'},
    {key:'canonicalUrl',label:'Canonical URL'},{key:'robots',label:'Robots',options:['index,follow','noindex,follow','noindex,nofollow'],type:'select'},
    {key:'ogTitle',label:'Open Graph title'},{key:'ogDescription',label:'Open Graph description',type:'textarea'},{key:'ogImageUrl',label:'Open Graph image URL'},
    {key:'structuredData',label:'JSON-LD structured data',type:'json'},{key:'active',label:'Active',type:'boolean'},
  ]},
  { resource: 'home-carousel', title: 'Homepage Carousel', description: 'Schedule hero slides, responsive images, calls-to-action and audience targeting.', columns: ['sortOrder','title','audience','startsAt','endsAt','active'], fields: [
    {key:'title',label:'Headline',required:true},{key:'subtitle',label:'Subtitle',type:'textarea'},{key:'eyebrow',label:'Eyebrow text'},
    {key:'imageUrl',label:'Desktop image URL'},{key:'mobileImageUrl',label:'Mobile image URL'},{key:'altText',label:'Image alt text'},
    {key:'primaryCta.label',label:'Primary button label'},{key:'primaryCta.url',label:'Primary button URL'},{key:'secondaryCta.label',label:'Secondary button label'},{key:'secondaryCta.url',label:'Secondary button URL'},
    {key:'textAlign',label:'Text alignment',type:'select',options:['left','center','right']},{key:'audience',label:'Audience',type:'select',options:['all','tenant','landlord','surveyor']},
    {key:'sortOrder',label:'Sort order',type:'number'},{key:'startsAt',label:'Start date'},{key:'endsAt',label:'End date'},{key:'active',label:'Active',type:'boolean'},
  ]},
  { resource: 'home-sections', title: 'Homepage Sections', description: 'Control statistics, featured content, locations, testimonials and calls-to-action.', columns: ['sortOrder','key','type','title','active'], fields: [
    {key:'key',label:'Unique key',required:true},{key:'type',label:'Section type',type:'select',options:['stats','features','featured_properties','featured_surveyors','locations','testimonials','cta','custom'],required:true},
    {key:'title',label:'Title'},{key:'subtitle',label:'Subtitle',type:'textarea'},{key:'content',label:'Section content JSON',type:'json'},{key:'sortOrder',label:'Sort order',type:'number'},{key:'active',label:'Active',type:'boolean'},
  ]},
  { resource: 'property-type-configs', title: 'Property Types', description: 'Configure property categories, hierarchy modes and allowed listing purposes.', columns: ['sortOrder','label','category','hierarchyMode','active'], fields: [
    {key:'key',label:'Key',required:true},{key:'label',label:'Display label',required:true},{key:'category',label:'Category',type:'select',options:['residential','commercial','land','hospitality','event','other']},
    {key:'hierarchyMode',label:'Hierarchy mode',type:'select',options:['simple','building','apartment_building','pg_hostel','commercial','land']},{key:'allowedPurposes',label:'Purposes',type:'array'},{key:'fields',label:'Dynamic form fields JSON',type:'json'},{key:'sortOrder',label:'Sort order',type:'number'},{key:'active',label:'Active',type:'boolean'},
  ]},
  { resource: 'area-units', title: 'Area Units', description: 'Manage regional conversion values for square feet, square metres, Bigha, Katha, Lessa and other units.', columns: ['sortOrder','label','symbol','squareMetreFactor','active'], fields: [
    {key:'key',label:'Key',required:true},{key:'label',label:'Label',required:true},{key:'symbol',label:'Symbol'},{key:'squareMetreFactor',label:'Square metre factor',type:'number',required:true},
    {key:'region.country',label:'Country'},{key:'region.state',label:'State'},{key:'region.district',label:'District'},{key:'sortOrder',label:'Sort order',type:'number'},{key:'active',label:'Active',type:'boolean'},
  ]},
  { resource: 'landlord-plans', title: 'Landlord Plans', description: 'Set building, apartment, room, bed, public listing, tenant, storage and team limits.', columns: ['rank','name','prices.monthly','limits.buildings','limits.apartments','limits.rooms','active'], fields: [
    {key:'key',label:'Plan key',required:true},{key:'name',label:'Plan name',required:true},{key:'description',label:'Description',type:'textarea'},{key:'rank',label:'Rank',type:'number'},
    {key:'prices.monthly',label:'Monthly price',type:'number'},{key:'prices.yearly',label:'Yearly price',type:'number'},{key:'limits.properties',label:'Properties',type:'number'},
    {key:'limits.buildings',label:'Buildings',type:'number'},{key:'limits.apartments',label:'Apartments',type:'number'},{key:'limits.rooms',label:'Rooms',type:'number'},{key:'limits.beds',label:'Beds',type:'number'},
    {key:'limits.publicListings',label:'Public listings',type:'number'},{key:'limits.activeTenants',label:'Active tenants',type:'number'},{key:'limits.storageMB',label:'Storage MB',type:'number'},{key:'limits.teamMembers',label:'Team members',type:'number'},
    {key:'features.rentAutomation',label:'Rent automation',type:'boolean'},{key:'features.advancedReports',label:'Advanced reports',type:'boolean'},{key:'features.propertyPromotions',label:'Promotions',type:'boolean'},
    {key:'features.tenantInterviews',label:'Tenant interviews',type:'boolean'},{key:'features.utilityBilling',label:'Utility billing',type:'boolean'},{key:'features.apiAccess',label:'API access',type:'boolean'},
    {key:'graceDays',label:'Grace period days',type:'number'},{key:'featured',label:'Featured plan',type:'boolean'},{key:'active',label:'Active',type:'boolean'},
  ]},
];

function AssetUpload({ value, onChange, label }: { value?: string; onChange: (value:string)=>void; label:string }) {
  const [working,setWorking]=useState(false);
  async function upload(event: ChangeEvent<HTMLInputElement>) { const file=event.target.files?.[0]; if(!file)return; setWorking(true); try { const result=await uploadSiteAsset(file); onChange(result.data.url); } finally { setWorking(false); event.target.value=''; } }
  return <Stack spacing={1}><TextField label={label} value={value || ''} onChange={(event)=>onChange(event.target.value)} fullWidth size="small" /><Button component="label" variant="outlined" startIcon={working?<CircularProgress size={16}/>:<UploadRounded/>} disabled={working}>Upload image<input hidden type="file" accept="image/*" onChange={upload}/></Button>{value&&<Box component="img" src={value} alt={label} sx={{height:72,maxWidth:220,objectFit:'contain',border:'1px solid',borderColor:'divider',borderRadius:2,p:1}}/>}</Stack>;
}

function CollectionEditor({ definition }: { definition: CollectionDefinition }) {
  const [rows,setRows]=useState<any[]>([]); const [loading,setLoading]=useState(true); const [error,setError]=useState(''); const [dialog,setDialog]=useState<{row?:any}|null>(null); const [form,setForm]=useState<FormShape>({});
  async function load(){setLoading(true);setError('');try{setRows((await getResource(definition.resource,{limit:100})).data);}catch(e){setError((e as Error).message);}finally{setLoading(false);}}
  useEffect(()=>{load();},[definition.resource]);
  function open(row?:any){const next:FormShape={};definition.fields.forEach((field)=>{const value=get(row||{},field.key);next[field.key]=field.type==='array'&&Array.isArray(value)?value.join(', '):field.type==='json'&&value?JSON.stringify(value,null,2):value??(field.type==='boolean'?false:'');});setForm(next);setDialog({row});}
  async function save(){try{const payload:FormShape={};definition.fields.forEach((field)=>{let value=form[field.key];if(field.type==='number')value=value===''?undefined:Number(value);if(field.type==='boolean')value=Boolean(value);if(field.type==='array')value=String(value||'').split(',').map((item)=>item.trim()).filter(Boolean);if(field.type==='json'&&typeof value==='string'&&value.trim())value=JSON.parse(value);if(value!==''&&value!==undefined)set(payload,field.key,value);});dialog?.row?await updateResource(definition.resource,dialog.row._id,payload):await createResource(definition.resource,payload);setDialog(null);await load();}catch(e){setError((e as Error).message);}}
  async function remove(row:any){if(!confirm(`Delete ${row.title||row.name||row.label||row.key}?`))return;try{await deleteResource(definition.resource,row._id);await load();}catch(e){setError((e as Error).message);}}
  return <Stack spacing={2}>
    <Stack direction={{xs:'column',sm:'row'}} justifyContent="space-between" spacing={1}><Box><Typography variant="h6" fontWeight={900}>{definition.title}</Typography><Typography color="text.secondary" fontSize={13}>{definition.description}</Typography></Box><Stack direction="row" spacing={1}><Button startIcon={<RefreshRounded/>} onClick={load}>Refresh</Button><Button variant="contained" startIcon={<AddRounded/>} onClick={()=>open()}>Add</Button></Stack></Stack>
    {error&&<Alert severity="error">{error}</Alert>}
    {loading?<CircularProgress/>:<Grid container spacing={1.5}>{rows.map((row)=><Grid size={{xs:12,md:6,xl:4}} key={row._id}><Card variant="outlined" sx={{height:'100%',borderRadius:3}}><CardContent><Stack direction="row" justifyContent="space-between"><Box sx={{minWidth:0}}><Typography fontWeight={850} noWrap>{row.title||row.name||row.label||row.path||row.key}</Typography><Stack direction="row" gap={.7} flexWrap="wrap" mt={1}>{definition.columns.slice(1).map((column)=><Chip key={column} size="small" label={`${sentence(column.split('.').at(-1)||column)}: ${String(get(row,column) ?? '—')}`} variant="outlined"/>)}</Stack></Box><Stack><IconButton onClick={()=>open(row)}><EditRounded/></IconButton><IconButton color="error" onClick={()=>remove(row)}><DeleteRounded/></IconButton></Stack></Stack></CardContent></Card></Grid>)}</Grid>}
    {!loading&&!rows.length&&<Paper variant="outlined" sx={{p:5,textAlign:'center',borderStyle:'dashed'}}><Typography fontWeight={800}>No records yet</Typography></Paper>}
    <Dialog open={Boolean(dialog)} onClose={()=>setDialog(null)} fullWidth maxWidth="md"><DialogTitle fontWeight={900}>{dialog?.row?'Edit':'Add'} {definition.title}</DialogTitle><DialogContent dividers><Grid container spacing={2}>{definition.fields.map((field)=><Grid size={{xs:12,sm:field.type==='textarea'||field.type==='json'?12:6}} key={field.key}>{field.type==='boolean'?<FormControlLabel control={<Switch checked={Boolean(form[field.key])} onChange={(_,checked)=>setForm((old)=>({...old,[field.key]:checked}))}/>} label={field.label}/>:<TextField fullWidth size="small" select={field.type==='select'} multiline={field.type==='textarea'||field.type==='json'} rows={field.type==='json'?7:field.type==='textarea'?3:undefined} type={field.type==='number'?'number':'text'} required={field.required} label={field.label} value={form[field.key]??''} onChange={(event)=>setForm((old)=>({...old,[field.key]:event.target.value}))}>{field.options?.map((option)=><MenuItem key={option} value={option}>{sentence(option)}</MenuItem>)}</TextField>}</Grid>)}</Grid></DialogContent><DialogActions><Button onClick={()=>setDialog(null)}>Cancel</Button><Button variant="contained" startIcon={<SaveRounded/>} onClick={save}>Save</Button></DialogActions></Dialog>
  </Stack>;
}

export default function SiteAdministrationPage(){
  const [tab,setTab]=useState(0);const [settings,setSettings]=useState<FormShape>({});const [settingsId,setSettingsId]=useState('');const [loading,setLoading]=useState(true);const [error,setError]=useState('');const [saved,setSaved]=useState('');const {refresh}=useSite();
  async function load(){setLoading(true);try{const rows=(await getResource('site-settings',{limit:1})).data;const row=rows[0]||{};setSettings(row);setSettingsId(row._id||'');}catch(e){setError((e as Error).message);}finally{setLoading(false);}}
  useEffect(()=>{load();},[]);
  async function saveSettings(){try{const payload={...settings};delete payload._id;delete payload.createdAt;delete payload.updatedAt;delete payload.__v;settingsId?await updateResource('site-settings',settingsId,payload):await createResource('site-settings',payload);setSaved('Site settings published');await load();await refresh();}catch(e){setError((e as Error).message);}}
  const tabs=useMemo(()=>['Site Identity',...definitions.map((item)=>item.title)],[]);
  if(loading)return <Box sx={{py:16,display:'grid',placeItems:'center'}}><CircularProgress/></Box>;
  return <Box sx={{px:{xs:2,sm:3,lg:4},pb:6}}><Stack direction={{xs:'column',md:'row'}} justifyContent="space-between" spacing={2} mb={3}><Box><Typography variant="h4" fontWeight={950}>Site & Marketplace Administration</Typography><Typography color="text.secondary">Publish branding, SEO, homepage content, property types, area units and subscription plans directly from MongoDB.</Typography></Box>{tab===0&&<Button variant="contained" startIcon={<SaveRounded/>} onClick={saveSettings}>Publish site settings</Button>}</Stack>
  {error&&<Alert severity="error" onClose={()=>setError('')} sx={{mb:2}}>{error}</Alert>}{saved&&<Alert severity="success" onClose={()=>setSaved('')} sx={{mb:2}}>{saved}</Alert>}
  <Paper variant="outlined" sx={{borderRadius:4,overflow:'hidden'}}><Tabs value={tab} onChange={(_,value)=>setTab(value)} variant="scrollable" scrollButtons="auto" sx={{px:2,borderBottom:'1px solid',borderColor:'divider'}}>{tabs.map((label)=><Tab key={label} label={label}/>)}</Tabs><Box sx={{p:{xs:2,md:3}}}>{tab===0?<Stack spacing={3}><Box><Typography variant="h6" fontWeight={900}>Brand and identity</Typography><Typography color="text.secondary" fontSize={13}>These values drive the navigation logo, browser metadata, footer, colours and public pages.</Typography></Box><Grid container spacing={2}>{siteFields.filter(([key])=>!['logoUrl','logoLightUrl','faviconUrl','defaultOgImageUrl'].includes(key)).map(([key,label])=><Grid size={{xs:12,md:key==='description'||key==='tagline'||key==='contact.address'?12:6}} key={key}><TextField fullWidth size="small" multiline={key==='description'||key==='tagline'||key==='contact.address'} rows={key==='description'?4:undefined} label={label} value={get(settings,key)??''} onChange={(event)=>setSettings((old)=>set({...old},key,event.target.value))} type={key.includes('Color')?'color':'text'}/></Grid>)}</Grid><Divider/><Typography variant="h6" fontWeight={900}>Brand assets</Typography><Grid container spacing={2}>{[['logoUrl','Primary logo'],['logoLightUrl','Light logo'],['faviconUrl','Favicon'],['defaultOgImageUrl','Social image']].map(([key,label])=><Grid size={{xs:12,md:6}} key={key}><AssetUpload label={label} value={get(settings,key)} onChange={(value)=>setSettings((old)=>set({...old},key,value))}/></Grid>)}</Grid><Divider/><Stack direction="row" gap={3} flexWrap="wrap"><FormControlLabel control={<Switch checked={Boolean(get(settings,'homepage.heroEnabled'))} onChange={(_,value)=>setSettings((old)=>set({...old},'homepage.heroEnabled',value))}/>} label="Homepage hero"/><FormControlLabel control={<Switch checked={Boolean(get(settings,'homepage.featuredPropertiesEnabled'))} onChange={(_,value)=>setSettings((old)=>set({...old},'homepage.featuredPropertiesEnabled',value))}/>} label="Featured properties"/><FormControlLabel control={<Switch checked={Boolean(get(settings,'homepage.featuredSurveyorsEnabled'))} onChange={(_,value)=>setSettings((old)=>set({...old},'homepage.featuredSurveyorsEnabled',value))}/>} label="Featured surveyors"/><FormControlLabel control={<Switch checked={Boolean(get(settings,'homepage.statsEnabled'))} onChange={(_,value)=>setSettings((old)=>set({...old},'homepage.statsEnabled',value))}/>} label="Homepage statistics"/><FormControlLabel control={<Switch checked={Boolean(get(settings,'maintenance.enabled'))} onChange={(_,value)=>setSettings((old)=>set({...old},'maintenance.enabled',value))}/>} label="Maintenance mode"/></Stack></Stack>:<CollectionEditor definition={definitions[tab-1]}/>}</Box></Paper></Box>;
}
