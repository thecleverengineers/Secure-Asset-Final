import { useEffect, useMemo, useState, type FormEvent } from 'react';
import { Alert, Box, Button, Card, CardContent, Chip, Container, Divider, Grid, LinearProgress, Snackbar, Stack, TextField, Typography } from '@mui/material';
import CheckRoundedIcon from '@mui/icons-material/CheckRounded';
import MailOutlineRoundedIcon from '@mui/icons-material/MailOutlineRounded';
import PhoneRoundedIcon from '@mui/icons-material/PhoneRounded';
import LocationOnOutlinedIcon from '@mui/icons-material/LocationOnOutlined';
import AutoAwesomeRoundedIcon from '@mui/icons-material/AutoAwesomeRounded';
import ShieldOutlinedIcon from '@mui/icons-material/ShieldOutlined';
import DescriptionOutlinedIcon from '@mui/icons-material/DescriptionOutlined';
import SmartphoneRoundedIcon from '@mui/icons-material/SmartphoneRounded';
import ApartmentRoundedIcon from '@mui/icons-material/ApartmentRounded';
import EngineeringRoundedIcon from '@mui/icons-material/EngineeringRounded';
import PaymentsRoundedIcon from '@mui/icons-material/PaymentsRounded';
import { useSite } from '../context/SiteContext';
import { submitSiteEnquiry } from '../services/api';

const fallbackFeatures = [
  { icon: ShieldOutlinedIcon, title: 'Verified tenant journeys', desc: 'KYC, applications, interviews, agreements and tenancy records in one secure workflow.' },
  { icon: ApartmentRoundedIcon, title: 'Flexible property hierarchy', desc: 'Manage buildings, floors, apartments, rooms, beds, commercial units and land.' },
  { icon: PaymentsRoundedIcon, title: 'Rent and utility automation', desc: 'Generate invoices, calculate meter-based bills, issue receipts and send reminders.' },
  { icon: DescriptionOutlinedIcon, title: 'Document Vault', desc: 'Private cloud storage for property, survey, legal, payment and identity records.' },
  { icon: EngineeringRoundedIcon, title: 'Professional surveyor marketplace', desc: 'Find verified surveyors, request quotations and manage field projects and reports.' },
  { icon: SmartphoneRoundedIcon, title: 'Mobile-first operations', desc: 'Manage visits, field data, photos, approvals and payments on any device.' },
];

export function Home() {
  const { data, loading } = useSite();
  const settings = data.settings || {};
  const slides = data.carousel || [];
  const [index, setIndex] = useState(0);
  useEffect(() => {
    if (slides.length < 2) return;
    const timer = window.setInterval(() => setIndex((value) => (value + 1) % slides.length), 6000);
    return () => window.clearInterval(timer);
  }, [slides.length]);
  const slide = slides[index];
  const statsSection = data.sections.find((item) => item.type === 'stats');
  const featureSection = data.sections.find((item) => item.type === 'features');
  const stats = Array.isArray(statsSection?.content?.items) ? statsSection.content.items : [
    { value: 'Multi-role', label: 'Tenant, Landlord and Surveyor modes' },
    { value: 'Private by default', label: 'Documents and legal records' },
    { value: 'Database driven', label: 'Listings, content and workflows' },
    { value: 'Production ready', label: 'Node.js, MongoDB and PM2' },
  ];
  const features = Array.isArray(featureSection?.content?.items) ? featureSection.content.items.map((item: any, idx: number) => ({ ...item, icon: fallbackFeatures[idx % fallbackFeatures.length].icon })) : fallbackFeatures;
  const primary = settings.brand?.primaryColor || '#0B5270';

  return (
    <Box sx={{ bgcolor: '#FAFAFA' }}>
      {loading && <LinearProgress />}
      {settings.homepage?.heroEnabled !== false && <Box sx={{ minHeight: { xs: 560, md: 650 }, display: 'grid', placeItems: 'center', position: 'relative', overflow: 'hidden', color: slide?.imageUrl ? 'white' : '#0f172a', bgcolor: slide?.imageUrl ? '#0f172a' : '#f8fafc' }}>
        {slide?.imageUrl && <Box component="img" src={slide.imageUrl} alt={slide.altText || slide.title} sx={{ position: 'absolute', inset: 0, width: '100%', height: '100%', objectFit: 'cover' }} />}
        {slide?.imageUrl && <Box sx={{ position: 'absolute', inset: 0, bgcolor: `rgba(2, 8, 23, ${slide.overlay?.enabled === false ? 0 : slide.overlay?.opacity ?? 0.45})` }} />}
        <Container maxWidth="lg" sx={{ position: 'relative', zIndex: 1, textAlign: slide?.textAlign || 'center', py: 10 }}>
          <Chip label={slide?.eyebrow || 'Property · Tenant · Survey · Legal Records'} sx={{ mb: 3, bgcolor: slide?.imageUrl ? 'rgba(255,255,255,.14)' : `${primary}14`, color: slide?.imageUrl ? 'white' : primary, fontWeight: 800 }} />
          <Typography variant="h1" sx={{ maxWidth: 920, mx: slide?.textAlign === 'left' ? 0 : 'auto', fontWeight: 900, letterSpacing: '-.045em', fontSize: { xs: '2.7rem', md: '4.8rem' }, lineHeight: 1.04 }}>
            {slide?.title || settings.tagline || 'The complete operating system for property and survey management.'}
          </Typography>
          <Typography sx={{ maxWidth: 720, mx: slide?.textAlign === 'left' ? 0 : 'auto', mt: 3, fontSize: { xs: '1rem', md: '1.2rem' }, lineHeight: 1.7, color: slide?.imageUrl ? 'rgba(255,255,255,.78)' : '#64748b' }}>
            {slide?.subtitle || settings.description || 'Manage property listings, tenant selection, KYC, site visits, rent, utilities, survey projects and secure documents from one account.'}
          </Typography>
          <Stack direction={{ xs: 'column', sm: 'row' }} spacing={2} justifyContent={slide?.textAlign === 'left' ? 'flex-start' : 'center'} sx={{ mt: 5 }}>
            <Button variant="contained" size="large" href={slide?.primaryCta?.url || '/marketplace'} sx={{ bgcolor: primary, px: 4, py: 1.5 }}>{slide?.primaryCta?.label || 'Browse Properties'}</Button>
            <Button variant="outlined" size="large" href={slide?.secondaryCta?.url || '/login'} sx={{ px: 4, py: 1.5, color: slide?.imageUrl ? 'white' : primary, borderColor: slide?.imageUrl ? 'rgba(255,255,255,.45)' : `${primary}55` }}>{slide?.secondaryCta?.label || 'Open Dashboard'}</Button>
          </Stack>
          {slides.length > 1 && <Stack direction="row" spacing={1} justifyContent={slide?.textAlign === 'left' ? 'flex-start' : 'center'} sx={{ mt: 5 }}>{slides.map((_item, dot) => <Box key={dot} onClick={() => setIndex(dot)} sx={{ width: dot === index ? 28 : 9, height: 9, borderRadius: 99, cursor: 'pointer', bgcolor: dot === index ? primary : slide?.imageUrl ? 'rgba(255,255,255,.45)' : '#cbd5e1', transition: '.2s' }} />)}</Stack>}
        </Container>
      </Box>}

      {settings.homepage?.statsEnabled !== false && <Box sx={{ bgcolor: primary, color: 'white', py: 4 }}>
        <Container maxWidth="lg"><Grid container spacing={2}>{stats.map((item: any) => <Grid size={{ xs: 6, md: 3 }} key={item.label}><Box sx={{ textAlign: 'center' }}><Typography sx={{ fontWeight: 900, fontSize: { xs: '1.3rem', md: '1.8rem' } }}>{item.value}</Typography><Typography sx={{ opacity: .68, fontSize: '.78rem', mt: .4 }}>{item.label}</Typography></Box></Grid>)}</Grid></Container>
      </Box>}

      <Container maxWidth="lg" sx={{ py: { xs: 8, md: 12 } }}>
        <Box sx={{ textAlign: 'center', mb: 7 }}><Typography sx={{ fontWeight: 900, fontSize: { xs: '2rem', md: '2.8rem' }, letterSpacing: '-.035em' }}>{featureSection?.title || 'Everything connected to the database'}</Typography><Typography sx={{ color: '#64748b', maxWidth: 680, mx: 'auto', mt: 2 }}>{featureSection?.subtitle || 'No static dashboards or placeholder content. Every number, listing, limit, approval, bill, gallery and homepage block comes from MongoDB.'}</Typography></Box>
        <Grid container spacing={3}>{features.map((feature: any) => { const Icon = feature.icon || AutoAwesomeRoundedIcon; return <Grid size={{ xs: 12, sm: 6, md: 4 }} key={feature.title}><Card elevation={0} sx={{ height: '100%', border: '1px solid #e2e8f0', borderRadius: 4 }}><CardContent sx={{ p: 3.5 }}><Box sx={{ width: 48, height: 48, display: 'grid', placeItems: 'center', borderRadius: 3, bgcolor: `${primary}12`, color: primary, mb: 2.5 }}><Icon /></Box><Typography sx={{ fontWeight: 850, fontSize: '1rem' }}>{feature.title}</Typography><Typography sx={{ color: '#64748b', mt: 1, lineHeight: 1.65, fontSize: '.88rem' }}>{feature.desc || feature.description}</Typography></CardContent></Card></Grid>; })}</Grid>
      </Container>
    </Box>
  );
}

export function Pricing() {
  const { data } = useSite(); const plans = data.landlordPlans || []; const primary = data.settings?.brand?.primaryColor || '#0B5270';
  return <Box sx={{ bgcolor: '#FAFAFA', minHeight: '100vh' }}><Box sx={{ bgcolor: primary, py: { xs: 6, md: 8 }, textAlign: 'center', color: 'white' }}><Container maxWidth="md"><Typography sx={{ fontWeight: 900, fontSize: { xs: '2.1rem', md: '3rem' } }}>Landlord plans that scale by structure</Typography><Typography sx={{ mt: 1.5, opacity: .72 }}>Buildings, apartments, rooms, beds, tenants, storage and public listings are counted separately.</Typography></Container></Box><Container maxWidth="xl" sx={{ py: { xs: 6, md: 10 } }}><Grid container spacing={3}>{plans.map((plan: any) => <Grid size={{ xs: 12, md: 6, lg: 3 }} key={plan.key}><Card elevation={0} sx={{ height: '100%', borderRadius: 4, border: plan.featured ? `2px solid ${primary}` : '1px solid #e2e8f0', position: 'relative' }}>{plan.featured && <Chip label="Most Popular" sx={{ position: 'absolute', top: -14, left: '50%', transform: 'translateX(-50%)', bgcolor: primary, color: 'white' }} />}<CardContent sx={{ p: 3.5 }}><Typography sx={{ fontWeight: 900, fontSize: '1.25rem' }}>{plan.name}</Typography><Typography sx={{ color: '#64748b', minHeight: 62, mt: 1 }}>{plan.description}</Typography><Typography sx={{ fontWeight: 900, fontSize: '2.2rem', mt: 2, color: primary }}>{plan.key === 'enterprise' ? 'Custom' : `₹${Number(plan.prices?.monthly || 0).toLocaleString('en-IN')}`}<Typography component="span" sx={{ color: '#94a3b8', fontSize: '.85rem' }}>{plan.key === 'enterprise' ? '' : '/month'}</Typography></Typography><Divider sx={{ my: 2.5 }} /><Stack spacing={1.25}>{[['Buildings', plan.limits?.buildings], ['Apartments', plan.limits?.apartments], ['Rooms', plan.limits?.rooms], ['Beds', plan.limits?.beds], ['Public listings', plan.limits?.publicListings], ['Active tenants', plan.limits?.activeTenants], ['Storage', `${Math.round(Number(plan.limits?.storageMB || 0) / 1024)} GB`]].map(([label, value]) => <Stack direction="row" spacing={1} key={String(label)}><CheckRoundedIcon sx={{ color: primary, fontSize: 18 }} /><Typography sx={{ fontSize: '.86rem' }}>{label}: <b>{Number(value) >= 1000000 ? 'Unlimited' : String(value)}</b></Typography></Stack>)}</Stack><Button href="/login" fullWidth variant={plan.featured ? 'contained' : 'outlined'} sx={{ mt: 3 }}>{plan.key === 'enterprise' ? 'Contact Sales' : 'Choose Plan'}</Button></CardContent></Card></Grid>)}</Grid></Container></Box>;
}

export function About() {
  const { data } = useSite(); const settings = data.settings || {}; const primary = settings.brand?.primaryColor || '#0B5270';
  return <Box sx={{ bgcolor: '#FAFAFA', minHeight: '100vh' }}><Box sx={{ bgcolor: primary, color: 'white', py: { xs: 7, md: 10 } }}><Container maxWidth="md"><Typography sx={{ fontWeight: 900, fontSize: { xs: '2.2rem', md: '3.3rem' } }}>About {settings.siteTitle || 'SecureAsset'}</Typography><Typography sx={{ mt: 2, opacity: .75, fontSize: '1.05rem', lineHeight: 1.7 }}>{settings.description || settings.tagline}</Typography></Container></Box><Container maxWidth="lg" sx={{ py: { xs: 7, md: 10 } }}><Grid container spacing={5}><Grid size={{ xs: 12, md: 7 }}><Typography sx={{ fontWeight: 900, fontSize: '2rem', letterSpacing: '-.03em' }}>One account. Multiple professional capabilities.</Typography><Typography sx={{ color: '#475569', lineHeight: 1.85, mt: 2 }}>Every registered account begins as a Tenant account. The same person can activate Landlord Mode, Surveyor Mode, or both through subscriptions—without maintaining separate accounts. The platform connects public discovery with private operational workflows, secure records and auditable financial activity.</Typography></Grid><Grid size={{ xs: 12, md: 5 }}><Stack spacing={2}>{['Property and room marketplace', 'Tenant KYC and selection', 'Rent and utility automation', 'Surveyor marketplace and field operations', 'Universal legal document vault'].map((item) => <Card key={item} elevation={0} sx={{ border: '1px solid #e2e8f0', borderRadius: 3 }}><CardContent><Stack direction="row" spacing={1.5}><CheckRoundedIcon sx={{ color: primary }} /><Typography sx={{ fontWeight: 750 }}>{item}</Typography></Stack></CardContent></Card>)}</Stack></Grid></Grid></Container></Box>;
}

export function Contact() {
  const { data } = useSite(); const settings = data.settings || {}; const primary = settings.brand?.primaryColor || '#0B5270';
  const [form, setForm] = useState({ name: '', email: '', phone: '', message: '' }); const [sending, setSending] = useState(false); const [notice, setNotice] = useState('');
  async function submit(event: FormEvent) { event.preventDefault(); setSending(true); try { await submitSiteEnquiry(form); setNotice('Your message has been submitted.'); setForm({ name: '', email: '', phone: '', message: '' }); } catch (error: any) { setNotice(error.message || 'Could not submit the message'); } finally { setSending(false); } }
  const contactItems = useMemo(() => [{ icon: MailOutlineRoundedIcon, label: 'Email', value: settings.contact?.email }, { icon: PhoneRoundedIcon, label: 'Phone', value: settings.contact?.phone }, { icon: LocationOnOutlinedIcon, label: 'Address', value: settings.contact?.address }].filter((item) => item.value), [settings.contact]);
  return <Box sx={{ bgcolor: '#FAFAFA', minHeight: '100vh' }}><Box sx={{ bgcolor: primary, color: 'white', py: { xs: 7, md: 9 } }}><Container maxWidth="md"><Typography sx={{ fontWeight: 900, fontSize: { xs: '2.2rem', md: '3.1rem' } }}>Talk to our team</Typography><Typography sx={{ mt: 1.5, opacity: .72 }}>Ask about subscriptions, onboarding, enterprise setup or platform support.</Typography></Container></Box><Container maxWidth="lg" sx={{ py: { xs: 7, md: 10 } }}><Grid container spacing={6}><Grid size={{ xs: 12, md: 5 }}><Stack spacing={3}>{contactItems.map((item) => <Stack direction="row" spacing={2} key={item.label}><Box sx={{ width: 44, height: 44, borderRadius: 3, bgcolor: `${primary}12`, color: primary, display: 'grid', placeItems: 'center' }}><item.icon /></Box><Box><Typography sx={{ color: '#94a3b8', fontSize: '.72rem', fontWeight: 800, textTransform: 'uppercase' }}>{item.label}</Typography><Typography sx={{ fontWeight: 700 }}>{item.value}</Typography></Box></Stack>)}</Stack></Grid><Grid size={{ xs: 12, md: 7 }}><Card elevation={0} sx={{ border: '1px solid #e2e8f0', borderRadius: 4 }}><CardContent sx={{ p: { xs: 3, md: 4 } }}><Box component="form" onSubmit={submit}><Grid container spacing={2}><Grid size={{ xs: 12, sm: 6 }}><TextField fullWidth required label="Full name" value={form.name} onChange={(e) => setForm({ ...form, name: e.target.value })} /></Grid><Grid size={{ xs: 12, sm: 6 }}><TextField fullWidth label="Phone" value={form.phone} onChange={(e) => setForm({ ...form, phone: e.target.value })} /></Grid><Grid size={12}><TextField fullWidth label="Email" type="email" value={form.email} onChange={(e) => setForm({ ...form, email: e.target.value })} /></Grid><Grid size={12}><TextField fullWidth required multiline rows={5} label="Message" value={form.message} onChange={(e) => setForm({ ...form, message: e.target.value })} /></Grid><Grid size={12}><Button disabled={sending} type="submit" variant="contained" size="large">{sending ? 'Submitting…' : 'Send Message'}</Button></Grid></Grid></Box></CardContent></Card></Grid></Grid></Container><Snackbar open={Boolean(notice)} autoHideDuration={5000} onClose={() => setNotice('')}><Alert severity={notice.includes('submitted') ? 'success' : 'error'}>{notice}</Alert></Snackbar></Box>;
}
