import { useState, type FormEvent } from 'react';
import { useNavigate } from 'react-router';
import {
  Alert, Box, Button, Chip, CircularProgress, Container, Divider, IconButton, InputAdornment, Paper, Stack,
  TextField, Typography,
} from '@mui/material';
import { EmailRounded, LockRounded, PhoneAndroidRounded, VisibilityOffRounded, VisibilityRounded } from '@mui/icons-material';
import { LogoMark } from '../components/premium/LogoMark';
import { useAuth } from '../context/AuthContext';
import { forgotPassword, sendOtp } from '../services/api';

const demoAccounts = [
  ['Admin', 'admin@secureasset.in'], ['Manager', 'manager@secureasset.in'], ['Tenant / Landlord', 'tenant@secureasset.in'], ['Surveyor', 'surveyor@secureasset.in'],
];
type Mode = 'login' | 'register' | 'otp' | 'forgot';

export default function LoginPage() {
  const navigate = useNavigate();
  const auth = useAuth();
  const [mode, setMode] = useState<Mode>('login');
  const [name, setName] = useState('');
  const [email, setEmail] = useState('admin@secureasset.in');
  const [phone, setPhone] = useState('');
  const [password, setPassword] = useState('Demo@123');
  const [otp, setOtp] = useState('');
  const [otpSent, setOtpSent] = useState(false);
  const [showPassword, setShowPassword] = useState(false);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');
  const [message, setMessage] = useState('');

  async function submit(event: FormEvent) {
    event.preventDefault(); setLoading(true); setError(''); setMessage('');
    try {
      if (mode === 'login') await auth.login(email, password);
      if (mode === 'register') await auth.register({ name, email, phone, password });
      if (mode === 'forgot') { const r = await forgotPassword(email); setMessage(r.message || 'Reset instructions issued.'); setLoading(false); return; }
      if (mode === 'otp') {
        if (!otpSent) { const r = await sendOtp({ email }); setOtpSent(true); setMessage(r.developmentOtp ? `Development OTP: ${r.developmentOtp}` : 'OTP sent.'); setLoading(false); return; }
        await auth.verifyOtp({ email, otp });
      }
      navigate('/app/dashboard');
    } catch (e) { setError((e as Error).message); }
    finally { setLoading(false); }
  }

  function selectDemo(selectedEmail: string) { setMode('login'); setEmail(selectedEmail); setPassword('Demo@123'); setError(''); }

  return <Box sx={{ minHeight: '100vh', bgcolor: '#eef3f6', display: 'grid', placeItems: 'center', py: 4 }}>
    <Container maxWidth="lg"><Paper elevation={0} sx={{ overflow: 'hidden', borderRadius: 6, border: '1px solid rgba(11,82,112,.12)', boxShadow: '0 35px 80px rgba(7,63,86,.12)' }}><Box sx={{ display: 'grid', gridTemplateColumns: { xs: '1fr', md: '1.05fr .95fr' } }}>
      <Box sx={{ bgcolor: '#073F56', color: 'white', p: { xs: 4, md: 7 }, minHeight: { md: 680 }, display: 'flex', flexDirection: 'column' }}><LogoMark light /><Box sx={{ my: 'auto', py: 5 }}><Chip label="MongoDB + Node.js" sx={{ bgcolor: 'rgba(255,255,255,.12)', color: 'white', mb: 3 }} /><Typography sx={{ fontSize: { xs: 34, md: 50 }, fontWeight: 900, lineHeight: 1.05, letterSpacing: '-.055em' }}>Every property workflow.<br/>One secure platform.</Typography><Typography sx={{ mt: 2.5, maxWidth: 520, color: 'rgba(255,255,255,.68)', fontSize: 15, lineHeight: 1.8 }}>Manage properties, units, tenants, leases, payments, field surveys, applications, complaints and approvals with scoped access for every role.</Typography><Stack direction="row" flexWrap="wrap" gap={1} sx={{ mt: 4 }}>{['Role-based access', 'Offline surveys', 'Audit trails', 'Live messaging', 'CSV reports'].map((item) => <Chip key={item} label={item} variant="outlined" sx={{ borderColor: 'rgba(255,255,255,.25)', color: 'rgba(255,255,255,.82)' }} />)}</Stack></Box><Typography sx={{ fontSize: 11, color: 'rgba(255,255,255,.45)' }}>SecureAsset · Enterprise property and survey operations</Typography></Box>
      <Box sx={{ p: { xs: 3, sm: 5, md: 6 }, bgcolor: 'white' }}><Typography sx={{ fontSize: 28, fontWeight: 900, letterSpacing: '-.04em' }}>{mode === 'login' ? 'Welcome back' : mode === 'register' ? 'Create your account' : mode === 'otp' ? 'Passwordless login' : 'Reset password'}</Typography><Typography color="text.secondary" sx={{ mt: .8, mb: 3, fontSize: 13.5 }}>{mode === 'login' ? 'Sign in with your organisation account.' : mode === 'register' ? 'Every new account is a tenant account. Upgrade anytime to list and manage your own properties.' : mode === 'otp' ? 'Use a secure one-time password.' : 'We will issue a password reset token.'}</Typography>
        <Stack direction="row" spacing={1} sx={{ mb: 3, flexWrap: 'wrap', gap: .7 }}>{(['login', 'register', 'otp'] as Mode[]).map((item) => <Button key={item} size="small" variant={mode === item ? 'contained' : 'outlined'} onClick={() => { setMode(item); setOtpSent(false); setError(''); setMessage(''); }}>{item === 'otp' ? 'OTP login' : item}</Button>)}</Stack>
        {error && <Alert severity="error" sx={{ mb: 2 }}>{error}</Alert>}{message && <Alert severity="success" sx={{ mb: 2 }}>{message}</Alert>}
        <Box component="form" onSubmit={submit}><Stack spacing={2}>
          {mode === 'register' && <TextField label="Full name" value={name} onChange={(e) => setName(e.target.value)} required />}
          <TextField label="Email address" type="email" value={email} onChange={(e) => setEmail(e.target.value)} required InputProps={{ startAdornment: <InputAdornment position="start"><EmailRounded fontSize="small" /></InputAdornment> }} />
          {mode === 'register' && <TextField label="Phone number" value={phone} onChange={(e) => setPhone(e.target.value)} InputProps={{ startAdornment: <InputAdornment position="start"><PhoneAndroidRounded fontSize="small" /></InputAdornment> }} />}
          {['login', 'register'].includes(mode) && <TextField label="Password" type={showPassword ? 'text' : 'password'} value={password} onChange={(e) => setPassword(e.target.value)} required InputProps={{ startAdornment: <InputAdornment position="start"><LockRounded fontSize="small" /></InputAdornment>, endAdornment: <InputAdornment position="end"><IconButton onClick={() => setShowPassword((v) => !v)}>{showPassword ? <VisibilityOffRounded /> : <VisibilityRounded />}</IconButton></InputAdornment> }} />}
          {mode === 'otp' && otpSent && <TextField label="6-digit OTP" value={otp} onChange={(e) => setOtp(e.target.value.replace(/\D/g, '').slice(0, 6))} inputProps={{ maxLength: 6, style: { letterSpacing: '.4em', textAlign: 'center', fontSize: 20 } }} required />}
          <Button type="submit" variant="contained" size="large" disabled={loading} sx={{ py: 1.45, borderRadius: 3, fontWeight: 800 }}>{loading ? <CircularProgress size={22} color="inherit" /> : mode === 'login' ? 'Sign in' : mode === 'register' ? 'Create account' : mode === 'forgot' ? 'Issue reset instructions' : otpSent ? 'Verify OTP' : 'Send OTP'}</Button>
          {mode === 'login' && <Button size="small" onClick={() => setMode('forgot')}>Forgot password?</Button>}
        </Stack></Box>
        <Divider sx={{ my: 3 }}>Demo workspaces</Divider><Typography color="text.secondary" sx={{ fontSize: 11.5, mb: 1.5 }}>Choose a role. All demo accounts use <b>Demo@123</b>.</Typography><Stack direction="row" flexWrap="wrap" gap={1}>{demoAccounts.map(([label, account]) => <Chip key={account} clickable label={label} onClick={() => selectDemo(account)} color={email === account && mode === 'login' ? 'primary' : 'default'} variant={email === account && mode === 'login' ? 'filled' : 'outlined'} />)}</Stack>
      </Box>
    </Box></Paper></Container>
  </Box>;
}
