import { createBrowserRouter, Navigate } from 'react-router';
import { Alert, Box, Button, Typography } from '@mui/material';
import FrontLayout from './components/FrontLayout';
import { Home, Pricing, About, Contact } from './pages/DummyPages';
import MarketplacePage from './pages/MarketplacePage';
import PropertyDetailPage from './pages/PropertyDetailPage';
import SurveyorMarketplacePage from './pages/SurveyorMarketplacePage';
import SurveyorPublicProfilePage from './pages/SurveyorPublicProfilePage';
import SurveyorPrivateProfilePage from './pages/SurveyorPrivateProfilePage';
import LoginPage from './pages/LoginPage';
import PublicDrivePage from './pages/PublicDrivePage';
import ProtectedRoute from './components/shared/ProtectedRoute';
import AppShell from './components/layout/AppShell';
import RoleDashboardPage from './pages/app/RoleDashboardPage';
import ModulePage from './pages/app/ModulePage';

function AccessDenied() {
  return <Box sx={{ minHeight: '100vh', display: 'grid', placeItems: 'center', p: 3 }}><Box sx={{ textAlign: 'center', maxWidth: 480 }}><Alert severity="error" sx={{ mb: 2 }}>Access denied</Alert><Typography variant="h4" sx={{ fontWeight: 900 }}>You do not have access to this module.</Typography><Button href="/app/dashboard" variant="contained" sx={{ mt: 3 }}>Return to dashboard</Button></Box></Box>;
}

export const router = createBrowserRouter([
  {
    path: '/',
    Component: FrontLayout,
    children: [
      { index: true, Component: Home },
      { path: 'marketplace', Component: MarketplacePage },
      { path: 'marketplace/:id', Component: PropertyDetailPage },
      { path: 'surveyors', Component: SurveyorMarketplacePage },
      { path: 'surveyors/:id', Component: SurveyorPublicProfilePage },
      { path: 'surveyor-private/:id', Component: SurveyorPrivateProfilePage },
      { path: 'pricing', Component: Pricing },
      { path: 'about', Component: About },
      { path: 'contact', Component: Contact },
    ],
  },
  { path: '/login', Component: LoginPage },
  { path: '/public-drive/:type/:token', Component: PublicDrivePage },
  {
    path: '/app',
    Component: ProtectedRoute,
    children: [{
      Component: AppShell,
      children: [
        { index: true, element: <Navigate to="dashboard" replace /> },
        { path: 'dashboard', Component: RoleDashboardPage },
        { path: ':module', Component: ModulePage },
      ],
    }],
  },
  { path: '/dashboard', element: <Navigate to="/app/dashboard" replace /> },
  { path: '/access-denied', Component: AccessDenied },
  { path: '*', element: <Navigate to="/" replace /> },
]);
