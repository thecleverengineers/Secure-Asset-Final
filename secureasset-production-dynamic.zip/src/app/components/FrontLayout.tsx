import { useState, useEffect } from 'react';
import { Outlet, useLocation, useNavigate } from 'react-router';
import { AppBar, Box, Button, Container, Drawer, IconButton, Stack, Toolbar, Typography, Divider } from '@mui/material';
import MenuRoundedIcon from '@mui/icons-material/MenuRounded';
import SearchRoundedIcon from '@mui/icons-material/SearchRounded';
import CloseRoundedIcon from '@mui/icons-material/CloseRounded';
import StorefrontRoundedIcon from '@mui/icons-material/StorefrontRounded';
import SellRoundedIcon from '@mui/icons-material/SellRounded';
import EngineeringRoundedIcon from '@mui/icons-material/EngineeringRounded';
import InfoOutlinedIcon from '@mui/icons-material/InfoOutlined';
import MailOutlineRoundedIcon from '@mui/icons-material/MailOutlineRounded';
import ArrowForwardRoundedIcon from '@mui/icons-material/ArrowForwardRounded';
import DashboardRoundedIcon from '@mui/icons-material/DashboardRounded';
import { LogoMark } from '../components/premium/LogoMark';
import { getCurrentUser } from '../services/api';
import { useSite } from '../context/SiteContext';

const nav = [
  { label: 'Properties', path: '/marketplace', icon: StorefrontRoundedIcon },
  { label: 'Surveyors', path: '/surveyors', icon: EngineeringRoundedIcon },
  { label: 'Pricing', path: '/pricing', icon: SellRoundedIcon },
  { label: 'About', path: '/about', icon: InfoOutlinedIcon },
  { label: 'Contact', path: '/contact', icon: MailOutlineRoundedIcon }
];

export default function FrontLayout() {
  const navigate = useNavigate();
  const location = useLocation();
  const [open, setOpen] = useState(false);
  const [scrolled, setScrolled] = useState(false);
  const [currentUser, setCurrentUser] = useState<any>(null);
  const { data: site, refresh: refreshSite } = useSite();
  const settings = site.settings || {};
  const primary = settings.brand?.primaryColor || '#0B5270';
  const themeColors = { seaBlue: primary, seaBlueDark: settings.brand?.secondaryColor || '#073F56', seaBlueLight: primary };

  useEffect(() => {
    const handleScroll = () => {
      setScrolled(window.scrollY > 10);
    };
    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  useEffect(() => {
    const fetchUser = async () => {
      const user = await getCurrentUser();
      setCurrentUser(user);
    };
    fetchUser();
  }, []);


  useEffect(() => {
    refreshSite(location.pathname);
  }, [location.pathname]);

  useEffect(() => {
    const seo = site.seo || {};
    const defaults = settings.seo || {};
    const baseTitle = seo.title || defaults.defaultTitle || settings.siteTitle || 'SecureAsset';
    const template = defaults.titleTemplate || '%s';
    document.title = template.includes('%s') && baseTitle !== defaults.defaultTitle ? template.replace('%s', baseTitle) : baseTitle;

    const setMeta = (selector: string, attribute: 'name' | 'property', key: string, value?: string) => {
      let element = document.head.querySelector(selector) as HTMLMetaElement | null;
      if (!value) { element?.remove(); return; }
      if (!element) {
        element = document.createElement('meta');
        element.setAttribute(attribute, key);
        element.dataset.siteManaged = 'true';
        document.head.appendChild(element);
      }
      element.setAttribute('content', value);
    };
    const setLink = (rel: string, href?: string) => {
      let element = document.head.querySelector(`link[rel="${rel}"]`) as HTMLLinkElement | null;
      if (!href) { if (element?.dataset.siteManaged === 'true') element.remove(); return; }
      if (!element) {
        element = document.createElement('link');
        element.rel = rel;
        element.dataset.siteManaged = 'true';
        document.head.appendChild(element);
      }
      element.href = href;
    };
    const canonicalBase = String(defaults.canonicalBaseUrl || '').replace(/\/$/, '');
    const canonical = seo.canonicalUrl || (canonicalBase ? `${canonicalBase}${location.pathname === '/' ? '' : location.pathname}` : window.location.href.split('#')[0].split('?')[0]);
    const description = seo.description || defaults.defaultDescription || settings.description;
    const image = seo.ogImageUrl || settings.defaultOgImageUrl;

    setMeta('meta[name="description"]', 'name', 'description', description);
    setMeta('meta[name="keywords"]', 'name', 'keywords', Array.isArray(seo.keywords || defaults.keywords) ? (seo.keywords || defaults.keywords).join(', ') : seo.keywords || defaults.keywords);
    setMeta('meta[name="robots"]', 'name', 'robots', seo.robots || defaults.robots || 'index,follow');
    setMeta('meta[name="google-site-verification"]', 'name', 'google-site-verification', defaults.googleSiteVerification);
    setMeta('meta[property="og:title"]', 'property', 'og:title', seo.ogTitle || baseTitle);
    setMeta('meta[property="og:description"]', 'property', 'og:description', seo.ogDescription || description);
    setMeta('meta[property="og:image"]', 'property', 'og:image', image);
    setMeta('meta[property="og:type"]', 'property', 'og:type', seo.ogType || 'website');
    setMeta('meta[property="og:url"]', 'property', 'og:url', canonical);
    setMeta('meta[name="twitter:card"]', 'name', 'twitter:card', seo.twitterCard || 'summary_large_image');
    setMeta('meta[name="twitter:title"]', 'name', 'twitter:title', seo.ogTitle || baseTitle);
    setMeta('meta[name="twitter:description"]', 'name', 'twitter:description', seo.ogDescription || description);
    setMeta('meta[name="twitter:image"]', 'name', 'twitter:image', image);
    setLink('canonical', canonical);
    setLink('icon', settings.faviconUrl);

    const scriptId = 'site-json-ld';
    let script = document.getElementById(scriptId) as HTMLScriptElement | null;
    const structuredData = seo.structuredData || (canonicalBase ? {
      '@context': 'https://schema.org', '@type': 'Organization', name: settings.siteTitle || 'SecureAsset', url: canonicalBase,
      logo: settings.logoUrl || undefined, description: settings.description || undefined,
    } : null);
    if (structuredData) {
      if (!script) { script = document.createElement('script'); script.id = scriptId; script.type = 'application/ld+json'; document.head.appendChild(script); }
      script.textContent = JSON.stringify(structuredData);
    } else script?.remove();
  }, [site.seo, settings, location.pathname]);

  const navItems = (
    <Stack direction={{ xs: 'column', md: 'row' }} spacing={{ xs: 4, md: 5 }}>
      {nav.map(item => {
        const isActive = location.pathname === item.path;
        return (
          <Typography
            key={item.path}
            component="button"
            onClick={() => { navigate(item.path); setOpen(false); }}
            sx={{
              color: isActive ? '#ffffff' : 'rgba(255,255,255,0.7)',
              fontWeight: isActive ? 600 : 500,
              fontSize: '0.85rem',
              letterSpacing: '0.03em',
              textTransform: 'none',
              background: 'none',
              border: 'none',
              cursor: 'pointer',
              position: 'relative',
              p: 0,
              fontFamily: 'inherit',
              '&::after': {
                content: '""',
                position: 'absolute',
                bottom: -4,
                left: 0,
                width: isActive ? '100%' : '0%',
                height: '2px',
                bgcolor: '#ffffff',
                transition: 'width 0.3s cubic-bezier(0.4, 0, 0.2, 1)',
                borderRadius: '2px'
              },
              '&:hover': {
                color: '#ffffff',
                '&::after': { width: '100%' }
              }
            }}
          >
            {item.label}
          </Typography>
        );
      })}
    </Stack>
  );

  return (
    <Box className="flex flex-col min-h-screen bg-[#FAFAFA] font-sans selection:bg-slate-200">
      <AppBar 
        position="fixed" 
        elevation={scrolled ? 4 : 0} 
        sx={{ 
          bgcolor: themeColors.seaBlue, 
          transition: 'all 0.3s cubic-bezier(0.4, 0, 0.2, 1)',
          borderBottom: '1px solid rgba(255,255,255,0.08)'
        }}
      >
        <Container maxWidth="xl">
          <Toolbar disableGutters sx={{ minHeight: { xs: 56, md: 64 }, py: 0 }} className="flex justify-between items-center w-full">
            <Box className="flex-shrink-0 cursor-pointer transition-transform hover:opacity-90" onClick={() => navigate('/')}>
              <LogoMark light />
            </Box>
            
            <Box 
              className="hidden lg:flex items-center rounded-full py-1.5 pl-6 pr-1.5 cursor-pointer bg-white absolute left-1/2 -translate-x-1/2 shadow-sm hover:shadow-md transition-all"
              onClick={() => navigate('/marketplace')}
              sx={{
                border: '1px solid rgba(0,0,0,0.04)',
                transform: scrolled ? 'scale(0.95) translateX(-52%)' : 'scale(1) translateX(-50%)',
                opacity: 1
              }}
            >
              <Typography variant="body2" sx={{ fontWeight: 600, px: 2, color: '#0f172a', fontSize: '0.8rem', fontFamily: 'inherit' }}>Find assets</Typography>
              <Divider orientation="vertical" flexItem sx={{ my: 1, mx: 0.5, borderColor: 'rgba(0,0,0,0.06)' }} />
              <Typography variant="body2" sx={{ fontWeight: 600, px: 2, color: '#0f172a', fontSize: '0.8rem', fontFamily: 'inherit' }}>Verified rentals</Typography>
              <Divider orientation="vertical" flexItem sx={{ my: 1, mx: 0.5, borderColor: 'rgba(0,0,0,0.06)' }} />
              <Typography variant="body2" sx={{ fontWeight: 500, px: 2, color: '#64748b', fontSize: '0.8rem', fontFamily: 'inherit' }}>Trusted sellers</Typography>
              <Box sx={{ bgcolor: themeColors.seaBlue, color: 'white' }} className="rounded-full p-1.5 flex items-center justify-center ml-2 transition-transform hover:scale-105">
                <SearchRoundedIcon sx={{ fontSize: 16 }} />
              </Box>
            </Box>

            <Stack direction="row" spacing={4} alignItems="center">
              <Box className="hidden lg:flex">
                {navItems}
              </Box>
              
              {currentUser ? (
                <Button 
                  onClick={() => navigate('/dashboard')}
                  disableRipple
                  sx={{
                    display: { xs: 'none', sm: 'flex' },
                    borderRadius: 0,
                    textTransform: 'none',
                    fontWeight: 600,
                    fontSize: '0.85rem',
                    letterSpacing: '0.03em',
                    color: 'white',
                    px: 0,
                    minWidth: 'auto',
                    position: 'relative',
                    fontFamily: 'inherit',
                    '&::after': {
                      content: '""',
                      position: 'absolute',
                      bottom: 4,
                      left: 0,
                      width: '0%',
                      height: '2px',
                      bgcolor: 'white',
                      transition: 'width 0.3s cubic-bezier(0.4, 0, 0.2, 1)',
                      borderRadius: '2px'
                    },
                    '&:hover': {
                      background: 'none',
                      '&::after': { width: '100%' }
                    }
                  }}
                >
                  <DashboardRoundedIcon sx={{ fontSize: 18, mr: 1 }} />
                  Dashboard
                </Button>
              ) : (
                <Button 
                  onClick={() => navigate('/login')}
                  disableRipple
                  sx={{
                    display: { xs: 'none', sm: 'flex' },
                    borderRadius: 0,
                    textTransform: 'none',
                    fontWeight: 600,
                    fontSize: '0.85rem',
                    letterSpacing: '0.03em',
                    color: 'white',
                    px: 0,
                    minWidth: 'auto',
                    position: 'relative',
                    fontFamily: 'inherit',
                    '&::after': {
                      content: '""',
                      position: 'absolute',
                      bottom: 4,
                      left: 0,
                      width: '0%',
                      height: '2px',
                      bgcolor: 'white',
                      transition: 'width 0.3s cubic-bezier(0.4, 0, 0.2, 1)',
                      borderRadius: '2px'
                    },
                    '&:hover': {
                      background: 'none',
                      '&::after': { width: '100%' }
                    }
                  }}
                >
                  Log in
                </Button>
              )}
              
              <Button
                variant="contained"
                onClick={() => navigate('/contact')}
                disableElevation
                sx={{
                  display: { xs: 'none', md: 'flex' },
                  bgcolor: 'white',
                  color: themeColors.seaBlueDark,
                  borderRadius: '4px',
                  textTransform: 'none',
                  fontWeight: 700,
                  fontSize: '0.8rem',
                  letterSpacing: '0.04em',
                  px: 3,
                  py: 1,
                  fontFamily: 'inherit',
                  transition: 'all 0.2s',
                  '&:hover': {
                    bgcolor: 'rgba(255,255,255,0.9)',
                    transform: 'translateY(-1px)',
                    boxShadow: '0 4px 12px rgba(0,0,0,0.1)'
                  }
                }}
              >
                Get Started
              </Button>

              <IconButton 
                onClick={() => setOpen(true)}
                disableRipple
                sx={{ 
                  display: { lg: 'none' }, 
                  color: 'white',
                  p: 0,
                  '&:hover': { background: 'none', opacity: 0.8 }
                }}
              >
                <MenuRoundedIcon sx={{ fontSize: 26 }} />
              </IconButton>
            </Stack>
          </Toolbar>
        </Container>
      </AppBar>

      <Drawer 
        anchor="right" 
        open={open} 
        onClose={() => setOpen(false)} 
        elevation={0}
        PaperProps={{ 
          sx: { 
            width: { xs: '100%', sm: 380 }, 
            bgcolor: themeColors.seaBlueDark,
            color: 'white',
            display: 'flex', 
            flexDirection: 'column',
          } 
        }}
      >
        <Box sx={{ p: 4, display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
          <LogoMark light />
          <IconButton onClick={() => setOpen(false)} sx={{ color: 'rgba(255,255,255,0.7)', '&:hover': { color: 'white', bgcolor: 'rgba(255,255,255,0.1)' } }}>
            <CloseRoundedIcon />
          </IconButton>
        </Box>
        
        <Box sx={{ flexGrow: 1, px: 3, pt: 2 }}>
          <Stack spacing={1}>
            <Typography sx={{ px: 2, mb: 2, fontSize: '0.75rem', fontWeight: 600, letterSpacing: '0.1em', color: 'rgba(255,255,255,0.4)', textTransform: 'uppercase' }}>
              Navigation
            </Typography>
            {nav.map(item => {
              const isActive = location.pathname === item.path;
              const IconComponent = item.icon;
              return (
                <Box
                  key={item.path}
                  onClick={() => { navigate(item.path); setOpen(false); }}
                  sx={{
                    display: 'flex',
                    alignItems: 'center',
                    gap: 2,
                    px: 2,
                    py: 1.5,
                    borderRadius: '8px',
                    cursor: 'pointer',
                    bgcolor: isActive ? 'rgba(255,255,255,0.1)' : 'transparent',
                    transition: 'all 0.2s',
                    '&:hover': {
                      bgcolor: 'rgba(255,255,255,0.06)',
                      '& .nav-text, & .nav-icon': { color: 'white' }
                    }
                  }}
                >
                  <IconComponent 
                    className="nav-icon"
                    sx={{ 
                      fontSize: '1.25rem', 
                      color: isActive ? 'white' : 'rgba(255,255,255,0.5)',
                      transition: 'color 0.2s'
                    }} 
                  />
                  <Typography
                    className="nav-text"
                    sx={{
                      fontSize: '1rem',
                      fontWeight: isActive ? 600 : 500,
                      color: isActive ? 'white' : 'rgba(255,255,255,0.7)',
                      transition: 'color 0.2s',
                      fontFamily: 'inherit'
                    }}
                  >
                    {item.label}
                  </Typography>
                  {isActive && (
                    <Box sx={{ ml: 'auto', width: 4, height: 4, borderRadius: '50%', bgcolor: 'white' }} />
                  )}
                </Box>
              );
            })}
          </Stack>
        </Box>

        <Box sx={{ p: 4, pb: 6 }}>
          <Box sx={{ p: 3, borderRadius: '12px', bgcolor: 'rgba(0,0,0,0.15)', border: '1px solid rgba(255,255,255,0.05)' }}>
            <Typography sx={{ fontWeight: 600, fontSize: '0.9rem', mb: 1, color: 'white' }}>
              Ready to scale?
            </Typography>
            <Typography sx={{ fontWeight: 400, fontSize: '0.8rem', mb: 3, color: 'rgba(255,255,255,0.6)', lineHeight: 1.5 }}>
              Join thousands of premium property managers.
            </Typography>
            <Button 
              variant="contained" 
              fullWidth
              endIcon={<ArrowForwardRoundedIcon sx={{ fontSize: '1rem' }} />}
              disableElevation
              onClick={() => { navigate('/login'); setOpen(false); }} 
              sx={{ 
                bgcolor: 'white', 
                color: themeColors.seaBlueDark,
                py: 1.5, 
                borderRadius: '6px', 
                textTransform: 'none', 
                fontWeight: 700,
                fontSize: '0.85rem',
                letterSpacing: '0.02em',
                fontFamily: 'inherit',
                '&:hover': { bgcolor: 'rgba(255,255,255,0.9)' }
              }}
            >
              Log in to Dashboard
            </Button>
          </Box>
        </Box>
      </Drawer>

      <Box component="main" className="flex-grow flex flex-col pt-[64px]">
        <Outlet />
      </Box>

      <Box component="footer" sx={{ bgcolor: themeColors.seaBlueDark, color: '#f8fafc', pt: { xs: 10, md: 12 }, pb: 6, mt: 'auto' }}>
        <Container maxWidth="xl">
          <Stack direction={{ xs: 'column', md: 'row' }} justifyContent="space-between" spacing={8}>
            <Box sx={{ maxWidth: 360 }}>
              <Box sx={{ mb: 4 }}>
                <LogoMark light />
              </Box>
              <Typography sx={{ color: 'rgba(255,255,255,0.7)', fontSize: '0.85rem', lineHeight: 1.8, fontWeight: 500, fontFamily: 'inherit' }}>
                {settings.description || settings.tagline || 'A premium property operating system for rentals, tenancy, surveys and secure records.'}
              </Typography>
            </Box>
            
            <Stack direction={{ xs: 'column', sm: 'row' }} spacing={{ xs: 8, sm: 12, md: 16 }}>
              <Box className="flex flex-col space-y-4">
                <Typography sx={{ color: 'white', fontWeight: 700, fontSize: '0.75rem', letterSpacing: '0.12em', textTransform: 'uppercase', mb: 1, fontFamily: 'inherit' }}>Platform</Typography>
                {['Marketplace', 'Pricing', 'AI Trust'].map(item => (
                  <Typography key={item} sx={{ color: 'rgba(255,255,255,0.6)', fontSize: '0.85rem', fontWeight: 500, cursor: 'pointer', transition: 'color 0.2s', '&:hover': { color: 'white' } }}>{item}</Typography>
                ))}
              </Box>
              <Box className="flex flex-col space-y-4">
                <Typography sx={{ color: 'white', fontWeight: 700, fontSize: '0.75rem', letterSpacing: '0.12em', textTransform: 'uppercase', mb: 1, fontFamily: 'inherit' }}>Operations</Typography>
                {['Rent automation', 'Document vault', 'Surveyor reports'].map(item => (
                  <Typography key={item} sx={{ color: 'rgba(255,255,255,0.6)', fontSize: '0.85rem', fontWeight: 500, cursor: 'pointer', transition: 'color 0.2s', '&:hover': { color: 'white' } }}>{item}</Typography>
                ))}
              </Box>
              <Box className="flex flex-col space-y-4">
                <Typography sx={{ color: 'white', fontWeight: 700, fontSize: '0.75rem', letterSpacing: '0.12em', textTransform: 'uppercase', mb: 1, fontFamily: 'inherit' }}>Access</Typography>
                {['OTP-only login', 'Mobile app', 'Admin console'].map(item => (
                  <Typography key={item} sx={{ color: 'rgba(255,255,255,0.6)', fontSize: '0.85rem', fontWeight: 500, cursor: 'pointer', transition: 'color 0.2s', '&:hover': { color: 'white' } }}>{item}</Typography>
                ))}
              </Box>
            </Stack>
          </Stack>
          
          <Divider sx={{ my: 6, borderColor: 'rgba(255,255,255,0.1)' }} />
          
          <Box sx={{ display: 'flex', flexDirection: { xs: 'column', md: 'row' }, justifyContent: 'space-between', alignItems: { xs: 'flex-start', md: 'center' }, gap: 3 }}>
            <Typography sx={{ color: 'rgba(255,255,255,0.5)', fontSize: '0.8rem', fontWeight: 500, fontFamily: 'inherit' }}>
              © {new Date().getFullYear()} {settings.siteTitle || 'SecureAsset'}. All rights reserved.
            </Typography>
            <Stack direction="row" spacing={5}>
              {['Privacy Policy', 'Terms of Service', 'Security'].map(item => (
                <Typography key={item} sx={{ color: 'rgba(255,255,255,0.5)', fontSize: '0.8rem', fontWeight: 500, cursor: 'pointer', transition: 'color 0.2s', '&:hover': { color: 'white' } }}>
                  {item}
                </Typography>
              ))}
            </Stack>
          </Box>
        </Container>
      </Box>
    </Box>
  );
}