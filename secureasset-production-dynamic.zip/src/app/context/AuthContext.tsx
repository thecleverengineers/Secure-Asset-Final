import { createContext, useContext, useEffect, useMemo, useState, type ReactNode } from 'react';
import type { User } from '../services/types';
import { clearSession, getCurrentUser, getMe, login as apiLogin, logout as apiLogout, register as apiRegister, verifyOtp as apiVerifyOtp } from '../services/api';

type AuthContextValue = {
  user: User | null;
  loading: boolean;
  isAuthenticated: boolean;
  login: (email: string, password: string) => Promise<User>;
  register: (body: { name: string; email: string; phone?: string; password: string }) => Promise<User>;
  verifyOtp: (body: { email?: string; phone?: string; otp: string }) => Promise<User>;
  logout: () => Promise<void>;
  refreshUser: () => Promise<void>;
};

const AuthContext = createContext<AuthContextValue | null>(null);

export function AuthProvider({ children }: { children: ReactNode }) {
  const [user, setUser] = useState<User | null>(() => getCurrentUser());
  const [loading, setLoading] = useState(true);

  async function refreshUser() {
    try { const result = await getMe(); setUser(result.data); localStorage.setItem('sa_user', JSON.stringify(result.data)); }
    catch { clearSession(); setUser(null); }
  }

  useEffect(() => { (async () => { if (getCurrentUser()) await refreshUser(); setLoading(false); })(); }, []);

  const value = useMemo<AuthContextValue>(() => ({
    user,
    loading,
    isAuthenticated: Boolean(user),
    async login(email, password) { const result = await apiLogin(email, password); setUser(result.data.user); return result.data.user; },
    async register(body) { const result = await apiRegister(body); setUser(result.data.user); return result.data.user; },
    async verifyOtp(body) { const result = await apiVerifyOtp(body); setUser(result.data.user); return result.data.user; },
    async logout() { try { await apiLogout(); } finally { setUser(null); } },
    refreshUser,
  }), [user, loading]);

  return <AuthContext.Provider value={value}>{children}</AuthContext.Provider>;
}

export function useAuth() {
  const value = useContext(AuthContext);
  if (!value) throw new Error('useAuth must be used inside AuthProvider');
  return value;
}
