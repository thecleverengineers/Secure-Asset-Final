import { createContext, useContext, useEffect, useMemo, useState, type ReactNode } from 'react';
import { getSiteConfig } from '../services/api';

export type SiteData = {
  settings: Record<string, any>;
  seo?: Record<string, any> | null;
  carousel: Record<string, any>[];
  sections: Record<string, any>[];
  landlordPlans: Record<string, any>[];
  propertyTypes: Record<string, any>[];
  areaUnits: Record<string, any>[];
};

type SiteContextValue = { data: SiteData; loading: boolean; refresh: (path?: string) => Promise<void> };
const defaults: SiteData = {
  settings: { siteTitle: 'SecureAsset', shortTitle: 'SecureAsset', tagline: 'Property, tenancy and survey management in one secure platform.', brand: { primaryColor: '#0B5270', secondaryColor: '#0f172a', accentColor: '#22c55e', fontFamily: 'Plus Jakarta Sans' }, contact: {}, social: {}, seo: {} },
  carousel: [], sections: [], landlordPlans: [], propertyTypes: [], areaUnits: [], seo: null,
};
const SiteContext = createContext<SiteContextValue>({ data: defaults, loading: true, refresh: async () => {} });

export function SiteProvider({ children }: { children: ReactNode }) {
  const [data, setData] = useState<SiteData>(defaults); const [loading, setLoading] = useState(true);
  async function refresh(path = window.location.pathname) {
    try { const response = await getSiteConfig(path); setData({ ...defaults, ...(response.data || {}) }); }
    catch { setData((current) => current); }
    finally { setLoading(false); }
  }
  useEffect(() => { refresh(); }, []);
  const value = useMemo(() => ({ data, loading, refresh }), [data, loading]);
  return <SiteContext.Provider value={value}>{children}</SiteContext.Provider>;
}
export function useSite() { return useContext(SiteContext); }
